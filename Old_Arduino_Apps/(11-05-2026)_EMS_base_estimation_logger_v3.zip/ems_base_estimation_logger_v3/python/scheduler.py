from __future__ import annotations

from dataclasses import dataclass

from ems_limits import EMS_LIMITS


@dataclass(frozen=True)
class SchedulerInputs:
    price_state: str
    pv_available: bool
    battery_soc: float
    pem_soc: float
    battery_voltage_V: float = 0.0


@dataclass(frozen=True)
class SchedulerDecision:
    scenario: int
    reason: str


def decide_scenario(inputs: SchedulerInputs) -> SchedulerDecision:
    low_price = str(inputs.price_state).upper() == "LOW"
    high_price = str(inputs.price_state).upper() == "HIGH"

    battery_voltage_available = inputs.battery_voltage_V > 0.1

    battery_voltage_high_for_charge = (
        battery_voltage_available
        and inputs.battery_voltage_V >= EMS_LIMITS.battery.charge_stop_voltage_control_V
    )

    battery_voltage_ok_for_discharge = (
        not battery_voltage_available
        or inputs.battery_voltage_V >= EMS_LIMITS.battery.min_voltage_discharge_V
    )

    battery_almost_full = (
        inputs.battery_soc >= EMS_LIMITS.battery.full_soc_control_percent
        or battery_voltage_high_for_charge
    )

    battery_can_discharge = (
        inputs.battery_soc > EMS_LIMITS.battery.min_soc_discharge_percent
        and battery_voltage_ok_for_discharge
    )

    pem_can_discharge = (
        inputs.pem_soc > EMS_LIMITS.pem.min_discharge_soc
    )

    if low_price:
        if not inputs.pv_available:
            return SchedulerDecision(
                scenario=1,
                reason="LOW price and PV unavailable -> grid supplies load.",
            )

        if battery_almost_full:
            return SchedulerDecision(
                scenario=3,
                reason=(
                    "LOW price, PV available and battery control limit reached "
                    "-> PV charges PEM."
                ),
            )

        return SchedulerDecision(
            scenario=2,
            reason="LOW price and PV available -> grid supplies load and PV charges battery.",
        )

    if high_price:
        if inputs.pv_available:
            return SchedulerDecision(
                scenario=4,
                reason="HIGH price and PV available -> PV supplies load.",
            )

        if battery_can_discharge:
            return SchedulerDecision(
                scenario=5,
                reason="HIGH price, PV unavailable and battery has energy -> battery supplies load.",
            )

        if pem_can_discharge:
            return SchedulerDecision(
                scenario=6,
                reason="HIGH price, PV unavailable, battery low and PEM has usable hydrogen -> PEM supplies load.",
            )

    return SchedulerDecision(
        scenario=1,
        reason="No local source available -> grid supplies load.",
    )