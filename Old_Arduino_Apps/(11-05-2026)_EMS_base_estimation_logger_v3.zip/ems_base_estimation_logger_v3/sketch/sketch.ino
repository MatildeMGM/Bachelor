#include <Arduino_RouterBridge.h>
#include <Wire.h>
#include <INA226_WE.h>
#include <math.h>

#define ADDR_BAT  0x40
#define ADDR_LOAD 0x41
#define ADDR_PV   0x44
#define ADDR_PEM  0x45

INA226_WE inaBat(&Wire, ADDR_BAT);
INA226_WE inaLoad(&Wire, ADDR_LOAD);
INA226_WE inaPV(&Wire, ADDR_PV);
INA226_WE inaPEM(&Wire, ADDR_PEM);

const int K1 = 8;
const int K2 = 2;
const int K3 = 3;
const int K4 = 4;
const int K5 = 5;
const int K6 = 7;
const int K7 = 9;

const int LOAD_SEQUENCE_TRIGGER_PIN = 10;

const int LEDS1 = 12;
const int LEDS2 = 0;
const int LEDS3 = 11;
const int LEDS4 = 6;
const int LEDS5 = 1;
const int LEDS6 = 13;

// Hard battery safety endpoints are based on the characterised lookup table.
// The discharge minimum uses the 0% discharge voltage. The charge maximum uses
// the 100% charge voltage. The EMS control limits in Python are kept slightly
// inside these hard safety limits.
const float BATTERY_SAFETY_MIN_DISCHARGE_VOLTAGE = 3.03315;
const float BATTERY_SAFETY_MAX_CHARGE_VOLTAGE = 4.34630;
const float BATTERY_EMS_MIN_DISCHARGE_VOLTAGE = 3.08315;
const float BATTERY_EMS_CHARGE_STOP_VOLTAGE = 4.29630;

const float BATTERY_MIN_VOLTAGE = BATTERY_SAFETY_MIN_DISCHARGE_VOLTAGE;
const float BATTERY_MAX_VOLTAGE = BATTERY_SAFETY_MAX_CHARGE_VOLTAGE;
const float BATTERY_USABLE_ENERGY_WH = 6.33;
const float BATTERY_NOMINAL_VOLTAGE = 3.7;
const float BATTERY_USABLE_CAPACITY_MAH = (BATTERY_USABLE_ENERGY_WH / BATTERY_NOMINAL_VOLTAGE) * 1000.0;

const int BATTERY_SOC_LOOKUP_POINTS = 16;

const float BATTERY_LOOKUP_SOC_PERCENT[BATTERY_SOC_LOOKUP_POINTS] = {
  0.0, 2.0, 5.0, 10.0, 15.0, 20.0, 30.0, 40.0,
  50.0, 60.0, 70.0, 80.0, 90.0, 95.0, 98.0, 100.0
};

const float BATTERY_LOOKUP_CHARGE_V[BATTERY_SOC_LOOKUP_POINTS] = {
  3.2256, 3.5411, 3.70655, 3.7298999999999998,
  3.7668999999999997, 3.797, 3.8234500000000002, 3.8521,
  3.8974, 3.9507, 4.0195, 4.1133, 4.21845,
  4.2793, 4.3194, 4.3463
};

const float BATTERY_LOOKUP_DISCHARGE_V[BATTERY_SOC_LOOKUP_POINTS] = {
  3.03315, 3.5124, 3.7214, 3.7698, 3.8077, 3.8366,
  3.8655, 3.889, 3.9229, 3.9803, 4.056, 4.1396,
  4.2348, 4.2858, 4.321, 4.35825
};

const float BATTERY_INITIAL_CURRENT_DEADBAND_MA = 5.0;
const float BATTERY_INITIAL_STABLE_VOLTAGE_DELTA_V = 0.015;
const unsigned long BATTERY_INITIAL_STABLE_TIME_MS = 3000;

const float BATTERY_REANCHOR_MIN_SOC_DIFFERENCE_PERCENT = 1.0;
const float BATTERY_REANCHOR_MAX_STORED_SOC_PERCENT = 1.0;

const float PEM_MIN_VOLTAGE = 0.54975;
const float PEM_MAX_VOLTAGE = 2.20;

const float MAX_CURRENT_A = 0.5;
const float MAX_POWER_W = 0.5;

bool inaBatOk = false;
bool inaLoadOk = false;
bool inaPVOk = false;
bool inaPEMOk = false;

int priceSlot = 0;
float electricityprice = 0.0;
bool priceReceived = false;

int requestedScenario = 1;
int activeScenario = 1;
bool scenarioReceived = false;
bool scenarioAccepted = true;
String lastRejectReason = "";
String lastError = "";

float nominalVoltage = 0.0;
float panelVoltage = 0.0;
float loadVoltage = 0.0;
float pemrfcVoltage = 0.0;
float batteryVoltage = 0.0;

float PVcurrent = 0.0;
float Loadcurrent = 0.0;
float PEMcurrent = 0.0;
float Batcurrent = 0.0;

float PVshuntVoltage_mV = 0.0;
float LoadshuntVoltage_mV = 0.0;
float PEMshuntVoltage_mV = 0.0;
float BatshuntVoltage_mV = 0.0;

float PVpower = 0.0;
float Loadpower = 0.0;
float PEMpower = 0.0;
float Batterypower = 0.0;

float batterySOC = 0.0;
float batteryCharge_mAh = 0.0;
float batteryCapacity_mAh = BATTERY_USABLE_CAPACITY_MAH;
float batteryEnergyWh = 0.0;
bool batterySOCInitialized = false;
String batterySOCStatus = "waiting_for_initial_soc";
float batteryInitialLookupVoltage = 0.0;
float batteryInitialCandidateVoltage = 0.0;
unsigned long batteryInitialStableStart = 0;
unsigned long lastBatterySOCUpdate = 0;
String batteryChargeState = "waiting_for_initial_soc";

String mode = "S1 Grid -> Load";

unsigned long lastPrint = 0;
const unsigned long printInterval = 2000;

bool setupINA(INA226_WE &sensor, const char* name);
float correctCurrent_A(byte address, float current_A);
float correctVoltage_V(byte address, float voltage_V);

void readMeasurements();
void updateBatterySOC();
float batteryLookupAverageVoltage(int index);
bool batteryVoltageInsideLookupRange(float voltage);
float estimateBatterySOCFromVoltage(float voltage);
bool batteryReadyForInitialSOC(unsigned long currentTime);
void initialiseBatterySOCFromLookup(unsigned long currentTime);
bool batteryReadyForSOCReanchor(unsigned long currentTime);
void reanchorBatterySOCFromLookup(unsigned long currentTime);
void resetBatterySOCEstimator();
String getBatteryChargeState(float soc);

void setLoadSequenceTrigger(bool active);

void applyScenario(int scenario);
bool scenarioIsSafe(int scenario);
void setScenarioLEDs(int scenario);
void allScenarioLEDsOff();
int relayPinFromName(String relayName);

void scenario1();
void scenario2();
void scenario3();
void scenario4();
void scenario5();
void scenario6();

bool apply_price_frame(String payload);
bool apply_scenario_frame(String payload);
bool apply_relay_frame(String payload);
bool apply_load_trigger_frame(String payload);
bool reset_battery_soc_estimator(String payload);
String get_status();

void printValues();

void setup() {
  Monitor.begin();
  delay(1000);
  Monitor.println("EMS Arduino safety layer started");

  Bridge.begin();
  Bridge.provide("apply_price_frame", apply_price_frame);
  Bridge.provide("apply_scenario_frame", apply_scenario_frame);
  Bridge.provide("apply_relay_frame", apply_relay_frame);
  Bridge.provide("apply_load_trigger_frame", apply_load_trigger_frame);
  Bridge.provide("reset_battery_soc_estimator", reset_battery_soc_estimator);
  Bridge.provide("get_status", get_status);

  Wire.begin();
  delay(500);

  inaBatOk = setupINA(inaBat, "INA226 Battery");
  inaLoadOk = setupINA(inaLoad, "INA226 Load");
  inaPVOk = setupINA(inaPV, "INA226 PV");
  inaPEMOk = setupINA(inaPEM, "INA226 PEMRFC");

  pinMode(K1, OUTPUT);
  pinMode(K2, OUTPUT);
  pinMode(K3, OUTPUT);
  pinMode(K4, OUTPUT);
  pinMode(K5, OUTPUT);
  pinMode(K6, OUTPUT);
  pinMode(K7, OUTPUT);

  pinMode(LOAD_SEQUENCE_TRIGGER_PIN, OUTPUT);
  digitalWrite(LOAD_SEQUENCE_TRIGGER_PIN, LOW);

  pinMode(LEDS1, OUTPUT);
  pinMode(LEDS2, OUTPUT);
  pinMode(LEDS3, OUTPUT);
  pinMode(LEDS4, OUTPUT);
  pinMode(LEDS5, OUTPUT);
  pinMode(LEDS6, OUTPUT);

  applyScenario(1);
}

void loop() {
  readMeasurements();
  updateBatterySOC();

  if (millis() - lastPrint >= printInterval) {
    lastPrint = millis();
    printValues();
  }

  delay(100);
}

bool setupINA(INA226_WE &sensor, const char* name) {
  Monitor.print("Initializing ");
  Monitor.print(name);
  Monitor.print(" ... ");

  if (!sensor.init()) {
    Monitor.println("FAILED");
    return false;
  }

  sensor.setAverage(INA226_AVERAGE_16);
  sensor.setConversionTime(INA226_CONV_TIME_1100);
  sensor.setMeasureMode(INA226_CONTINUOUS);
  sensor.waitUntilConversionCompleted();

  Monitor.println("OK");
  return true;
}

float correctCurrent_A(byte address, float current_A) {
  switch (address) {
    case ADDR_BAT:
      return current_A + 0.000563;

    case ADDR_LOAD:
      return current_A - 0.000033;

    case ADDR_PV:
      return current_A + 0.000138;

    case ADDR_PEM:
      return 0.843 * current_A + 0.001;

    default:
      return current_A;
  }
}

float correctVoltage_V(byte address, float voltage_V) {
  switch (address) {
    case ADDR_BAT:
      return voltage_V - 0.068;

    case ADDR_LOAD:
      return voltage_V - 0.066;

    case ADDR_PV:
      return voltage_V - 0.180;

    case ADDR_PEM:
      return voltage_V - 0.064;

    default:
      return voltage_V;
  }
}

void readMeasurements() {
  nominalVoltage = 5.0;

  if (inaBatOk) {
    inaBat.readAndClearFlags();
    batteryVoltage = correctVoltage_V(ADDR_BAT, inaBat.getBusVoltage_V());
    BatshuntVoltage_mV = inaBat.getShuntVoltage_mV();
    Batcurrent = correctCurrent_A(ADDR_BAT, inaBat.getCurrent_mA() / 1000.0);
    Batterypower = batteryVoltage * Batcurrent;
  }

  if (inaLoadOk) {
    inaLoad.readAndClearFlags();
    loadVoltage = correctVoltage_V(ADDR_LOAD, inaLoad.getBusVoltage_V());
    LoadshuntVoltage_mV = inaLoad.getShuntVoltage_mV();
    Loadcurrent = correctCurrent_A(ADDR_LOAD, inaLoad.getCurrent_mA() / 1000.0);
    Loadpower = loadVoltage * Loadcurrent;
  }

  if (inaPVOk) {
    inaPV.readAndClearFlags();
    panelVoltage = correctVoltage_V(ADDR_PV, inaPV.getBusVoltage_V());
    PVshuntVoltage_mV = inaPV.getShuntVoltage_mV();
    PVcurrent = correctCurrent_A(ADDR_PV, inaPV.getCurrent_mA() / 1000.0);
    PVpower = panelVoltage * PVcurrent;
  }

  if (inaPEMOk) {
    inaPEM.readAndClearFlags();
    pemrfcVoltage = correctVoltage_V(ADDR_PEM, inaPEM.getBusVoltage_V());
    PEMshuntVoltage_mV = inaPEM.getShuntVoltage_mV();
    PEMcurrent = correctCurrent_A(ADDR_PEM, inaPEM.getCurrent_mA() / 1000.0);
    PEMpower = pemrfcVoltage * PEMcurrent;
  }
}

void setLoadSequenceTrigger(bool active) {
  digitalWrite(LOAD_SEQUENCE_TRIGGER_PIN, active ? HIGH : LOW);
}

bool apply_price_frame(String payload) {
  if (!payload.startsWith("PRICE,")) {
    lastError = "invalid price frame";
    return false;
  }

  int firstComma = payload.indexOf(',');
  int secondComma = payload.indexOf(',', firstComma + 1);

  if (firstComma < 0 || secondComma < 0) {
    lastError = "invalid price commas";
    return false;
  }

  electricityprice = payload.substring(firstComma + 1, secondComma).toFloat();
  priceSlot = payload.substring(secondComma + 1).toInt();
  priceReceived = true;
  lastError = "";

  Monitor.print("Received price: ");
  Monitor.print(electricityprice, 5);
  Monitor.print(" DKK/kWh, slot ");
  Monitor.println(priceSlot);

  return true;
}

bool apply_scenario_frame(String payload) {
  if (!payload.startsWith("SCENARIO,") && !payload.startsWith("MANUAL_SCENARIO,")) {
    scenarioAccepted = false;
    lastRejectReason = "invalid scenario frame";
    lastError = lastRejectReason;
    return false;
  }

  int c1 = payload.indexOf(',');
  int c2 = payload.indexOf(',', c1 + 1);
  int c3 = payload.indexOf(',', c2 + 1);

  if (c1 < 0) {
    scenarioAccepted = false;
    lastRejectReason = "invalid scenario commas";
    lastError = lastRejectReason;
    return false;
  }

  int scenario = 1;

  if (c2 < 0) {
    scenario = payload.substring(c1 + 1).toInt();
  } else if (c3 >= 0) {
    scenario = payload.substring(c2 + 1, c3).toInt();
  } else {
    scenario = payload.substring(c1 + 1, c2).toInt();
  }

  if (scenario < 1 || scenario > 6) {
    scenarioAccepted = false;
    lastRejectReason = "scenario must be 1-6";
    lastError = lastRejectReason;
    return false;
  }

  requestedScenario = scenario;
  scenarioReceived = true;

  readMeasurements();

  if (!scenarioIsSafe(scenario)) {
    scenarioAccepted = false;
    lastError = lastRejectReason;
    return false;
  }

  applyScenario(scenario);

  scenarioAccepted = true;
  lastRejectReason = "";
  lastError = "";

  Monitor.print("Applied scenario S");
  Monitor.println(scenario);

  return true;
}

bool apply_relay_frame(String payload) {
  if (!payload.startsWith("RELAY,")) {
    lastError = "invalid relay frame";
    return false;
  }

  int c1 = payload.indexOf(',');
  int c2 = payload.indexOf(',', c1 + 1);

  if (c1 < 0 || c2 < 0) {
    lastError = "invalid relay commas";
    return false;
  }

  String relayName = payload.substring(c1 + 1, c2);
  relayName.trim();
  relayName.toUpperCase();

  int pin = relayPinFromName(relayName);

  if (pin < 0) {
    lastError = "unknown relay";
    return false;
  }

  int outputState = payload.substring(c2 + 1).toInt() ? HIGH : LOW;
  digitalWrite(pin, outputState);

  allScenarioLEDsOff();

  mode = "Manual relay " + relayName + (outputState == HIGH ? " HIGH" : " LOW");
  lastError = "";
  return true;
}

bool apply_load_trigger_frame(String payload) {
  if (!payload.startsWith("LOAD_TRIGGER,")) {
    lastError = "invalid load trigger frame";
    return false;
  }

  int c1 = payload.indexOf(',');

  if (c1 < 0) {
    lastError = "invalid load trigger commas";
    return false;
  }

  int value = payload.substring(c1 + 1).toInt();

  setLoadSequenceTrigger(value == 1);

  lastError = "";

  Monitor.print("Load sequence trigger D10 ");
  Monitor.println(value == 1 ? "HIGH" : "LOW");

  return true;
}

bool reset_battery_soc_estimator(String payload) {
  resetBatterySOCEstimator();
  readMeasurements();
  lastError = "";

  Monitor.println("Real battery SoC estimator reset; waiting for stable lookup voltage");

  return true;
}

bool scenarioIsSafe(int scenario) {
  lastRejectReason = "";

  if (inaBatOk && fabs(Batcurrent) > MAX_CURRENT_A) {
    lastRejectReason = "battery current limit exceeded";
    return false;
  }

  if (inaLoadOk && fabs(Loadcurrent) > MAX_CURRENT_A) {
    lastRejectReason = "load current limit exceeded";
    return false;
  }

  if (inaPVOk && fabs(PVcurrent) > MAX_CURRENT_A) {
    lastRejectReason = "PV current limit exceeded";
    return false;
  }

  if (inaPEMOk && fabs(PEMcurrent) > MAX_CURRENT_A) {
    lastRejectReason = "PEM current limit exceeded";
    return false;
  }

  if (inaBatOk && fabs(Batterypower) > MAX_POWER_W) {
    lastRejectReason = "battery power limit exceeded";
    return false;
  }

  if (inaLoadOk && fabs(Loadpower) > MAX_POWER_W) {
    lastRejectReason = "load power limit exceeded";
    return false;
  }

  if (inaPVOk && fabs(PVpower) > MAX_POWER_W) {
    lastRejectReason = "PV power limit exceeded";
    return false;
  }

  if (inaPEMOk && fabs(PEMpower) > MAX_POWER_W) {
    lastRejectReason = "PEM power limit exceeded";
    return false;
  }

  // Only the battery charging scenario is blocked by the charge maximum.
  // S1 must remain available as safe standby.
  if (scenario == 2 && inaBatOk && batteryVoltage > BATTERY_SAFETY_MAX_CHARGE_VOLTAGE) {
    lastRejectReason = "battery voltage above charge lookup safety maximum";
    return false;
  }

  if (inaPEMOk && pemrfcVoltage > PEM_MAX_VOLTAGE) {
    lastRejectReason = "PEM voltage above maximum";
    return false;
  }

  if (scenario == 4 && !inaPVOk) {
    lastRejectReason = "PV sensor not available for PV scenario";
    return false;
  }

  if (scenario == 5 && !inaBatOk) {
    lastRejectReason = "battery sensor not available for battery scenario";
    return false;
  }

  if (scenario == 6 && !inaPEMOk) {
    lastRejectReason = "PEM sensor not available for PEM scenario";
    return false;
  }

  if (scenario == 5 && batteryVoltage < BATTERY_SAFETY_MIN_DISCHARGE_VOLTAGE) {
    lastRejectReason = "battery voltage below discharge lookup safety minimum";
    return false;
  }

  if (scenario == 6 && pemrfcVoltage < PEM_MIN_VOLTAGE) {
    lastRejectReason = "PEM voltage too low for discharge";
    return false;
  }

  return true;
}

void applyScenario(int scenario) {
  if (scenario == 1) {
    scenario1();
  } else if (scenario == 2) {
    scenario2();
  } else if (scenario == 3) {
    scenario3();
  } else if (scenario == 4) {
    scenario4();
  } else if (scenario == 5) {
    scenario5();
  } else if (scenario == 6) {
    scenario6();
  } else {
    scenario1();
  }
}

String get_status() {
  readMeasurements();

  String payload = "";

  payload += "inaBatOk=" + String(inaBatOk ? 1 : 0);
  payload += ",inaLoadOk=" + String(inaLoadOk ? 1 : 0);
  payload += ",inaPVOk=" + String(inaPVOk ? 1 : 0);
  payload += ",inaPEMOk=" + String(inaPEMOk ? 1 : 0);

  payload += ",slot=" + String(priceSlot);
  payload += ",price=" + String(electricityprice, 5);
  payload += ",priceReceived=" + String(priceReceived ? 1 : 0);

  payload += ",panelVoltage=" + String(panelVoltage, 5);
  payload += ",batteryVoltage=" + String(batteryVoltage, 5);
  payload += ",pemrfcVoltage=" + String(pemrfcVoltage, 5);
  payload += ",loadVoltage=" + String(loadVoltage, 5);

  payload += ",PVcurrent=" + String(PVcurrent, 5);
  payload += ",Batcurrent=" + String(Batcurrent, 5);
  payload += ",PEMcurrent=" + String(PEMcurrent, 5);
  payload += ",Loadcurrent=" + String(Loadcurrent, 5);

  payload += ",PVcurrent_mA=" + String(PVcurrent * 1000.0, 3);
  payload += ",Batcurrent_mA=" + String(Batcurrent * 1000.0, 3);
  payload += ",PEMcurrent_mA=" + String(PEMcurrent * 1000.0, 3);
  payload += ",Loadcurrent_mA=" + String(Loadcurrent * 1000.0, 3);

  payload += ",PVshunt_mV=" + String(PVshuntVoltage_mV, 5);
  payload += ",Batshunt_mV=" + String(BatshuntVoltage_mV, 5);
  payload += ",PEMshunt_mV=" + String(PEMshuntVoltage_mV, 5);
  payload += ",Loadshunt_mV=" + String(LoadshuntVoltage_mV, 5);

  payload += ",PVpower=" + String(PVpower, 5);
  payload += ",Batterypower=" + String(Batterypower, 5);
  payload += ",PEMpower=" + String(PEMpower, 5);
  payload += ",Loadpower=" + String(Loadpower, 5);

  payload += ",PVpower_mW=" + String(PVpower * 1000.0, 3);
  payload += ",Batterypower_mW=" + String(Batterypower * 1000.0, 3);
  payload += ",PEMpower_mW=" + String(PEMpower * 1000.0, 3);
  payload += ",Loadpower_mW=" + String(Loadpower * 1000.0, 3);

  payload += ",batterySOC=" + String(batterySOC, 2);
  payload += ",batteryCharge_mAh=" + String(batteryCharge_mAh, 4);
  payload += ",batteryCapacity_mAh=" + String(batteryCapacity_mAh, 4);
  payload += ",batteryEnergyWh=" + String(batteryEnergyWh, 4);
  payload += ",batterySOCInitialized=" + String(batterySOCInitialized ? 1 : 0);
  payload += ",batterySOCStatus=" + batterySOCStatus;
  payload += ",batteryInitialLookupVoltage=" + String(batteryInitialLookupVoltage, 5);
  payload += ",batteryLookupEstimatedSOC=" + String(estimateBatterySOCFromVoltage(batteryVoltage), 2);
  payload += ",batteryLookupVoltageMin=" + String(batteryLookupAverageVoltage(0), 5);
  payload += ",batteryLookupVoltageMax=" + String(batteryLookupAverageVoltage(BATTERY_SOC_LOOKUP_POINTS - 1), 5);
  payload += ",batterySafetyMinDischargeVoltage=" + String(BATTERY_SAFETY_MIN_DISCHARGE_VOLTAGE, 5);
  payload += ",batterySafetyMaxChargeVoltage=" + String(BATTERY_SAFETY_MAX_CHARGE_VOLTAGE, 5);
  payload += ",batteryEMSMinDischargeVoltage=" + String(BATTERY_EMS_MIN_DISCHARGE_VOLTAGE, 5);
  payload += ",batteryEMSChargeStopVoltage=" + String(BATTERY_EMS_CHARGE_STOP_VOLTAGE, 5);
  payload += ",batteryChargeState=" + batteryChargeState;

  payload += ",K1=" + String(digitalRead(K1));
  payload += ",K2=" + String(digitalRead(K2));
  payload += ",K3=" + String(digitalRead(K3));
  payload += ",K4=" + String(digitalRead(K4));
  payload += ",K5=" + String(digitalRead(K5));
  payload += ",K6=" + String(digitalRead(K6));
  payload += ",K7=" + String(digitalRead(K7));

  payload += ",loadTrigger=" + String(digitalRead(LOAD_SEQUENCE_TRIGGER_PIN));

  payload += ",scenarioReceived=" + String(scenarioReceived ? 1 : 0);
  payload += ",scenarioAccepted=" + String(scenarioAccepted ? 1 : 0);
  payload += ",requestedScenario=" + String(requestedScenario);
  payload += ",activeScenario=" + String(activeScenario);

  payload += ",mode=" + mode;
  payload += ",lastRejectReason=" + lastRejectReason;
  payload += ",lastError=" + lastError;

  return payload;
}

float batteryLookupAverageVoltage(int index) {
  if (index < 0) {
    index = 0;
  }

  if (index >= BATTERY_SOC_LOOKUP_POINTS) {
    index = BATTERY_SOC_LOOKUP_POINTS - 1;
  }

  return 0.5 * (
    BATTERY_LOOKUP_CHARGE_V[index]
    + BATTERY_LOOKUP_DISCHARGE_V[index]
  );
}

bool batteryVoltageInsideLookupRange(float voltage) {
  return (
    voltage >= batteryLookupAverageVoltage(0)
    && voltage <= batteryLookupAverageVoltage(BATTERY_SOC_LOOKUP_POINTS - 1)
  );
}

float estimateBatterySOCFromVoltage(float voltage) {
  if (voltage <= batteryLookupAverageVoltage(0)) {
    return BATTERY_LOOKUP_SOC_PERCENT[0];
  }

  if (voltage >= batteryLookupAverageVoltage(BATTERY_SOC_LOOKUP_POINTS - 1)) {
    return BATTERY_LOOKUP_SOC_PERCENT[BATTERY_SOC_LOOKUP_POINTS - 1];
  }

  for (int i = 0; i < BATTERY_SOC_LOOKUP_POINTS - 1; i++) {
    float v0 = batteryLookupAverageVoltage(i);
    float v1 = batteryLookupAverageVoltage(i + 1);

    if (voltage >= v0 && voltage <= v1) {
      float soc0 = BATTERY_LOOKUP_SOC_PERCENT[i];
      float soc1 = BATTERY_LOOKUP_SOC_PERCENT[i + 1];

      if (fabs(v1 - v0) < 0.000001) {
        return soc0;
      }

      float fraction = (voltage - v0) / (v1 - v0);
      return soc0 + fraction * (soc1 - soc0);
    }
  }

  return BATTERY_LOOKUP_SOC_PERCENT[0];
}

bool batteryReadyForInitialSOC(unsigned long currentTime) {
  if (!batteryVoltageInsideLookupRange(batteryVoltage)) {
    batterySOCStatus = "waiting_for_voltage_in_lookup_range";
    batteryChargeState = batterySOCStatus;
    batteryInitialStableStart = 0;
    return false;
  }

  float batteryCurrent_mA = Batcurrent * 1000.0;

  if (fabs(batteryCurrent_mA) > BATTERY_INITIAL_CURRENT_DEADBAND_MA) {
    batterySOCStatus = "waiting_for_idle_battery_current";
    batteryChargeState = batterySOCStatus;
    batteryInitialStableStart = 0;
    return false;
  }

  if (
    batteryInitialStableStart == 0
    || fabs(batteryVoltage - batteryInitialCandidateVoltage) > BATTERY_INITIAL_STABLE_VOLTAGE_DELTA_V
  ) {
    batteryInitialCandidateVoltage = batteryVoltage;
    batteryInitialStableStart = currentTime;
    batterySOCStatus = "waiting_for_stable_battery_voltage";
    batteryChargeState = batterySOCStatus;
    return false;
  }

  if (currentTime - batteryInitialStableStart < BATTERY_INITIAL_STABLE_TIME_MS) {
    batterySOCStatus = "waiting_for_stable_battery_voltage";
    batteryChargeState = batterySOCStatus;
    return false;
  }

  return true;
}

void initialiseBatterySOCFromLookup(unsigned long currentTime) {
  batteryInitialLookupVoltage = batteryVoltage;
  batterySOC = estimateBatterySOCFromVoltage(batteryInitialLookupVoltage);
  batteryCharge_mAh = batteryCapacity_mAh * batterySOC / 100.0;
  batteryEnergyWh = (batteryCharge_mAh / 1000.0) * BATTERY_NOMINAL_VOLTAGE;
  batterySOCInitialized = true;
  batterySOCStatus = "initialised_from_lookup_table";
  lastBatterySOCUpdate = currentTime;
  batteryChargeState = getBatteryChargeState(batterySOC);
}

bool batteryReadyForSOCReanchor(unsigned long currentTime) {
  if (!batterySOCInitialized) {
    return false;
  }

  if (!batteryVoltageInsideLookupRange(batteryVoltage)) {
    return false;
  }

  float batteryCurrent_mA = Batcurrent * 1000.0;

  if (fabs(batteryCurrent_mA) > BATTERY_INITIAL_CURRENT_DEADBAND_MA) {
    return false;
  }

  float lookupSOC = estimateBatterySOCFromVoltage(batteryVoltage);

  return (
    batterySOC <= BATTERY_REANCHOR_MAX_STORED_SOC_PERCENT
    && lookupSOC >= batterySOC + BATTERY_REANCHOR_MIN_SOC_DIFFERENCE_PERCENT
  );
}

void reanchorBatterySOCFromLookup(unsigned long currentTime) {
  batteryInitialLookupVoltage = batteryVoltage;
  batterySOC = estimateBatterySOCFromVoltage(batteryInitialLookupVoltage);
  batteryCharge_mAh = batteryCapacity_mAh * batterySOC / 100.0;
  batteryEnergyWh = (batteryCharge_mAh / 1000.0) * BATTERY_NOMINAL_VOLTAGE;
  batterySOCInitialized = true;
  batterySOCStatus = "reanchored_from_lookup_table";
  lastBatterySOCUpdate = currentTime;
  batteryChargeState = getBatteryChargeState(batterySOC);
}

void resetBatterySOCEstimator() {
  batterySOC = 0.0;
  batteryCharge_mAh = 0.0;
  batteryEnergyWh = 0.0;
  batterySOCInitialized = false;
  batterySOCStatus = "waiting_for_initial_soc";
  batteryInitialLookupVoltage = 0.0;
  batteryInitialCandidateVoltage = 0.0;
  batteryInitialStableStart = 0;
  lastBatterySOCUpdate = 0;
  batteryChargeState = "waiting_for_initial_soc";
}

void updateBatterySOC() {
  unsigned long currentTime = millis();

  if (!inaBatOk) {
    batterySOCStatus = "waiting_for_battery_sensor";
    batteryChargeState = batterySOCStatus;
    return;
  }

  if (!batterySOCInitialized) {
    if (!batteryReadyForInitialSOC(currentTime)) {
      return;
    }

    initialiseBatterySOCFromLookup(currentTime);
    return;
  }

  if (batteryReadyForSOCReanchor(currentTime)) {
    reanchorBatterySOCFromLookup(currentTime);
    return;
  }

  float liveLookupSOC = estimateBatterySOCFromVoltage(batteryVoltage);

  if (
    batterySOCInitialized
    && batteryCharge_mAh <= 0.001
    && liveLookupSOC > 0.5
    && batteryVoltageInsideLookupRange(batteryVoltage)
    && fabs(Batcurrent * 1000.0) <= BATTERY_INITIAL_CURRENT_DEADBAND_MA
  ) {
    reanchorBatterySOCFromLookup(currentTime);
    return;
  }

  float dtHours = (currentTime - lastBatterySOCUpdate) / 3600000.0;
  lastBatterySOCUpdate = currentTime;

  batteryCharge_mAh += (Batcurrent * 1000.0) * dtHours;

  if (batteryCharge_mAh < 0.0) {
    batteryCharge_mAh = 0.0;
  }

  if (batteryCharge_mAh > batteryCapacity_mAh) {
    batteryCharge_mAh = batteryCapacity_mAh;
  }

  batterySOC = 100.0 * batteryCharge_mAh / batteryCapacity_mAh;
  batteryEnergyWh = (batteryCharge_mAh / 1000.0) * BATTERY_NOMINAL_VOLTAGE;
  batterySOCStatus = "current_integrated_after_lookup_initialisation";
  batteryChargeState = getBatteryChargeState(batterySOC);
}

String getBatteryChargeState(float soc) {
  if (soc <= 10.0) {
    return "empty";
  }

  if (soc <= 30.0) {
    return "low";
  }

  if (soc <= 70.0) {
    return "medium";
  }

  if (soc <= 90.0) {
    return "high";
  }

  return "full";
}

void printValues() {
  Monitor.print("Mode: ");
  Monitor.print(mode);

  Monitor.print(" Price: ");
  Monitor.print(electricityprice, 5);

  Monitor.print(" Slot: ");
  Monitor.print(priceSlot);

  Monitor.print(" PV V: ");
  Monitor.print(panelVoltage, 3);

  Monitor.print(" Bat V: ");
  Monitor.print(batteryVoltage, 3);

  Monitor.print(" Bat SoC: ");
  Monitor.print(batterySOC, 1);
  Monitor.print("% ");
  Monitor.print(batterySOCStatus);

  Monitor.print(" PEM V: ");
  Monitor.print(pemrfcVoltage, 3);

  Monitor.print(" Load mW: ");
  Monitor.print(Loadpower * 1000.0, 1);

  Monitor.print(" Load trigger: ");
  Monitor.print(digitalRead(LOAD_SEQUENCE_TRIGGER_PIN));

  Monitor.print(" Last error: ");
  Monitor.println(lastError);
}

void scenario1() {
  digitalWrite(K1, HIGH);
  digitalWrite(K2, LOW);
  digitalWrite(K3, HIGH);
  digitalWrite(K4, HIGH);
  digitalWrite(K5, HIGH);
  digitalWrite(K6, HIGH);
  digitalWrite(K7, HIGH);

  activeScenario = 1;
  mode = "S1 Grid -> Load";
  setScenarioLEDs(1);
}

void scenario2() {
  digitalWrite(K1, HIGH);
  digitalWrite(K2, LOW);
  digitalWrite(K3, LOW);
  digitalWrite(K4, HIGH);
  digitalWrite(K5, HIGH);
  digitalWrite(K6, HIGH);
  digitalWrite(K7, LOW);

  activeScenario = 2;
  mode = "S2 Grid -> Load and PV -> Battery";
  setScenarioLEDs(2);
}

void scenario3() {
  digitalWrite(K1, HIGH);
  digitalWrite(K2, LOW);
  digitalWrite(K3, HIGH);
  digitalWrite(K4, LOW);
  digitalWrite(K5, HIGH);
  digitalWrite(K6, HIGH);
  digitalWrite(K7, LOW);

  activeScenario = 3;
  mode = "S3 Grid -> Load and PV -> PEMRFC";
  setScenarioLEDs(3);
}

void scenario4() {
  digitalWrite(K1, LOW);
  digitalWrite(K2, HIGH);
  digitalWrite(K3, HIGH);
  digitalWrite(K4, HIGH);
  digitalWrite(K5, HIGH);
  digitalWrite(K6, HIGH);
  digitalWrite(K7, LOW);

  activeScenario = 4;
  mode = "S4 PV -> Load";
  setScenarioLEDs(4);
}

void scenario5() {
  digitalWrite(K1, LOW);
  digitalWrite(K2, LOW);
  digitalWrite(K3, HIGH);
  digitalWrite(K4, HIGH);
  digitalWrite(K5, LOW);
  digitalWrite(K6, HIGH);
  digitalWrite(K7, HIGH);

  activeScenario = 5;
  mode = "S5 Battery -> Load";
  setScenarioLEDs(5);
}

void scenario6() {
  digitalWrite(K1, LOW);
  digitalWrite(K2, LOW);
  digitalWrite(K3, HIGH);
  digitalWrite(K4, HIGH);
  digitalWrite(K5, HIGH);
  digitalWrite(K6, LOW);
  digitalWrite(K7, HIGH);

  activeScenario = 6;
  mode = "S6 PEM -> Load";
  setScenarioLEDs(6);
}

void setScenarioLEDs(int scenario) {
  digitalWrite(LEDS1, scenario == 1 ? HIGH : LOW);
  digitalWrite(LEDS2, scenario == 2 ? HIGH : LOW);
  digitalWrite(LEDS3, scenario == 3 ? HIGH : LOW);
  digitalWrite(LEDS4, scenario == 4 ? HIGH : LOW);
  digitalWrite(LEDS5, scenario == 5 ? HIGH : LOW);
  digitalWrite(LEDS6, scenario == 6 ? HIGH : LOW);
}

void allScenarioLEDsOff() {
  digitalWrite(LEDS1, LOW);
  digitalWrite(LEDS2, LOW);
  digitalWrite(LEDS3, LOW);
  digitalWrite(LEDS4, LOW);
  digitalWrite(LEDS5, LOW);
  digitalWrite(LEDS6, LOW);
}

int relayPinFromName(String relayName) {
  if (relayName == "K1") return K1;
  if (relayName == "K2") return K2;
  if (relayName == "K3") return K3;
  if (relayName == "K4") return K4;
  if (relayName == "K5") return K5;
  if (relayName == "K6") return K6;
  if (relayName == "K7") return K7;

  return -1;
}