from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path


class EMSLogger:
    """CSV logger for the EMS simulation run.

    The logger only writes after start() has been called from the WebUI.
    """

    def __init__(self, log_dir: str | Path = "logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.file_path: Path | None = None
        self.file = None
        self.writer: csv.DictWriter | None = None
        self.active = False

    def start(self) -> str:
        if self.active and self.file_path is not None:
            return str(self.file_path)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.file_path = self.log_dir / f"ems_log_{timestamp}.csv"
        self.file = self.file_path.open("w", newline="", encoding="utf-8")
        self.writer = csv.DictWriter(self.file, fieldnames=FIELDNAMES)
        self.writer.writeheader()
        self.file.flush()
        self.active = True
        return str(self.file_path)

    def stop(self) -> None:
        if self.file:
            self.file.flush()
            self.file.close()

        self.file = None
        self.writer = None
        self.active = False

    def log(self, state) -> None:
        if not self.active or not self.writer or not self.file:
            return

        status = getattr(state, "arduino_status", None) or {}
        actual_scenario = getattr(state, "actual_scenario", getattr(state, "scenario", 0))
        target_scenario = getattr(state, "target_scenario", 0)
        scenario_for_grid = actual_scenario or target_scenario
        load_power = _float(status.get("Loadpower"))
        grid_power = load_power if scenario_for_grid in {1, 2, 3} else 0.0

        row = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "simulation_running": getattr(state, "simulation_running", False),
            "demo_cycle": getattr(state, "demo_cycle", 0),
            "current_slot": getattr(state, "current_slot", 0),
            "current_time_label": getattr(state, "current_time_label", ""),
            "current_interval_label": getattr(state, "current_interval_label", ""),
            "price_date": getattr(state, "price_date", ""),
            "price_zone": getattr(state, "price_zone", ""),
            "price_dkk_per_kwh": getattr(state, "current_price", 0.0),
            "price_threshold_dkk_per_kwh": getattr(state, "price_threshold", 0.0),
            "price_state": getattr(state, "price_state", ""),
            "demand_w": getattr(state, "current_demand_w", 0.0),
            "demand_mw": getattr(state, "current_demand_w", 0.0) * 1000.0,
            "control_mode": getattr(state, "control_mode", ""),
            "target_scenario": target_scenario,
            "actual_scenario": actual_scenario,
            "reason": getattr(state, "reason", ""),
            "battery_soc_percent": getattr(state, "battery_soc", 0.0),
            "pem_soc_percent": getattr(state, "pem_soc", 0.0),
            "h2_volume_ml": getattr(state, "h2_volume_mL", 0.0),
            "h2_usable_ml": getattr(state, "h2_usable_mL", 0.0),
            "h2_mode": getattr(state, "h2_mode", ""),
            "pv_latched_available": getattr(state, "pv_latched_available", False),
            "pv_mode": getattr(state, "pv_mode", ""),
            "panel_voltage_v": _float(status.get("panelVoltage")),
            "pv_current_a": _float(status.get("PVcurrent")),
            "pv_power_w": _float(status.get("PVpower")),
            "battery_voltage_v": _float(status.get("batteryVoltage")),
            "battery_current_a": _float(status.get("Batcurrent")),
            "battery_power_w": _float(status.get("Batterypower")),
            "pem_voltage_v": _float(status.get("pemrfcVoltage", status.get("PEMvoltage"))),
            "pem_current_a": _float(status.get("PEMcurrent")),
            "pem_power_w": _float(status.get("PEMpower")),
            "load_voltage_v": _float(status.get("loadVoltage")),
            "load_current_a": _float(status.get("Loadcurrent")),
            "load_power_w": load_power,
            "grid_power_w": grid_power,
            "bridge_ok": getattr(state, "bridge_ok", False),
            "last_error": getattr(state, "last_error", ""),
        }

        self.writer.writerow(row)
        self.file.flush()


def _float(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


FIELDNAMES = [
    "timestamp",
    "simulation_running",
    "demo_cycle",
    "current_slot",
    "current_time_label",
    "current_interval_label",
    "price_date",
    "price_zone",
    "price_dkk_per_kwh",
    "price_threshold_dkk_per_kwh",
    "price_state",
    "demand_w",
    "demand_mw",
    "control_mode",
    "target_scenario",
    "actual_scenario",
    "reason",
    "battery_soc_percent",
    "pem_soc_percent",
    "h2_volume_ml",
    "h2_usable_ml",
    "h2_mode",
    "pv_latched_available",
    "pv_mode",
    "panel_voltage_v",
    "pv_current_a",
    "pv_power_w",
    "battery_voltage_v",
    "battery_current_a",
    "battery_power_w",
    "pem_voltage_v",
    "pem_current_a",
    "pem_power_w",
    "load_voltage_v",
    "load_current_a",
    "load_power_w",
    "grid_power_w",
    "bridge_ok",
    "last_error",
]
