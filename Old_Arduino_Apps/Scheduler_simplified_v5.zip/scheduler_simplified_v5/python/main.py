"""
Simplified EMS controller with WebUI timeline.

One Python file only:
- Hosts the WebUI.
- Reads status from sketch.ino through Arduino_RouterBridge.
- Applies the simplified 6-scenario automatic logic.
- Sends Scenario 1-6 commands to the Arduino sketch.
- Updates virtual Battery SoC and PEM SoC by integrating measured current.
- Uses latched PV availability:
    * PV voltage > 3 V is used only to initially detect PV.
    * Once PV is latched as available, it only becomes unavailable if PV power < 10 mW.
- Fetches day-ahead electricity prices and builds a 96-step timeline.
- Loads the 96-step demand curve from CSV.
- The plot shows future demand/API prices and logs actual INA readings over time.

Scenario 7 and 8 are intentionally removed.
"""

from __future__ import annotations

import csv
import json
import math
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen
from zoneinfo import ZoneInfo

from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge
from logger import EMSLogger


# ---------------------------------------------------------------------------
# General settings
# ---------------------------------------------------------------------------

BRIDGE_TIMEOUT = 1.0
LOOP_SECONDS = 1.0

DK_TZ = ZoneInfo("Europe/Copenhagen")
PRICE_API_URL = "https://api.energidataservice.dk/dataset/DayAheadPrices"
BASE_URL = PRICE_API_URL
PRICE_SOURCE = "api.energidataservice.dk"
VALID_PRICE_ZONES = ("DK1", "DK2")
PRICE_REQUEST_TIMEOUT = 8

APP_DIR = Path(__file__).resolve().parent
APP_ROOT = APP_DIR.parent
LOG_DIR = APP_ROOT / "logs"
DEMAND_PROFILE_PATH = APP_DIR / "data" / "variable_load_signal" / "scaled_may_power_profile_15min.csv"
MIN_DEMAND_POWER_MW = 20.0

# Demonstration timeline: one 24-hour day is replayed in 12 real minutes.
# This is only used for the 96-step plot index and API price lookup.
DEMO_DAY_SECONDS = 12 * 60
DEMO_SLOT_COUNT = 96
DEMO_SLOT_SECONDS = DEMO_DAY_SECONDS / DEMO_SLOT_COUNT

PV_AVAILABLE_VOLTAGE = 3.6
PV_MIN_POWER_W = 0.000  # 10 mW
PV_LATCH_OFF_DELAY_SECONDS = 1.0

SCENARIOS = {
    1: "S1: Grid -> Load",
    2: "S2: Grid -> Load, PV -> Battery",
    3: "S3: Grid -> Load, PV -> PEMRFC",
    4: "S4: PV -> Load",
    5: "S5: Battery -> Load",
    6: "S6: PEM -> Load",
}


# ---------------------------------------------------------------------------
# Virtual SoC settings
# ---------------------------------------------------------------------------

BATTERY_CAPACITY_MAH = 10.0

PEM_DISCHARGE_CAPACITY_MAH = 10.0
PEM_CHARGE_CAPACITY_MAH = 20.0
# PEM charging capacity is 20 mAh because efficiency is approximately 50%.
# This means it needs about 20 mAh of charging current-time to reach 100%,
# but only contains about 10 mAh of usable discharge capacity.

MIN_SOC = 0.0
MAX_SOC = 100.0

MAX_SOC_INTEGRATION_DT_SECONDS = 10.0
last_soc_update_time = time.time()

# Hydrogen estimator settings. The values are intentionally explicit and local to
# main.py so the app still stays single-script. With a 10 mAh usable PEM store and
# ~50% charging efficiency, a full charge needs about 20 mAh = 72 C.
H2_MIN_USABLE_ML = 0.0
H2_MAX_ML = 10.0
H2_CHARGE_ML_PER_C = (H2_MAX_ML - H2_MIN_USABLE_ML) / (PEM_CHARGE_CAPACITY_MAH * 3.6)
H2_DISCHARGE_ML_PER_C = (H2_MAX_ML - H2_MIN_USABLE_ML) / (PEM_DISCHARGE_CAPACITY_MAH * 3.6)
PEM_CHARGE_CURRENT_THRESHOLD_A = 0.001
PEM_DISCHARGE_CURRENT_THRESHOLD_A = -0.001


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

@dataclass
class ControllerState:
    control_mode: str = "manual"  # "manual" or "auto"

    # Price can be controlled manually or from the 96-step API timeline.
    price_mode: str = "api"       # "api" or "manual"
    price_state: str = "LOW"      # "LOW" or "HIGH"
    price_zone: str = "DK2"
    price_date: str = ""
    current_price: float = 0.0
    price_threshold: float = 0.0
    prices: list[float] | None = None
    last_price_update: str = ""
    price_source: str = PRICE_SOURCE

    # Built-in 96-step demand profile.
    demand_profile: list[float] | None = None
    current_demand_w: float = 0.0
    last_demand_update: str = ""

    # Demo timeline index.
    demo_start_time: float = time.time()
    demo_cycle: int = 0
    current_slot: int = 0
    current_time_label: str = "00:00"
    current_interval_label: str = "00:00-00:15"

    pv_mode: str = "auto"         # "auto", "force_available", "force_unavailable"
    pv_latched_available: bool = False
    pv_low_power_since: float | None = None

    battery_soc: float = 50.0
    pem_soc: float = 50.0

    h2_volume_mL: float = 5.0
    h2_usable_mL: float = 5.0
    h2_usable_soc: float = 50.0
    h2_last_delta_mL: float = 0.0
    h2_mode: str = "idle"

    target_scenario: int = 1
    actual_scenario: int = 1

    reason: str = "Manual mode: waiting for command."
    bridge_ok: bool = False
    last_error: str = ""

    arduino_status: dict | None = None

    # 96-step timeline input data. The WebUI uses this for full-day demand and
    # API prices. Planned flows are kept in the payload for debugging but are not
    # drawn as future INA readings.
    timeline: dict | None = None

    # Live 96-step history from INA readings. The plot only draws these values
    # where real measurements have been logged.
    live_history: dict | None = None

    # The simulation/logging timeline does not advance until Start is pressed in the WebUI.
    simulation_running: bool = False
    logging_enabled: bool = False
    log_file: str = ""
    last_log_update: str = ""


ui = WebUI()
state = ControllerState()
logger = EMSLogger(LOG_DIR)
state_lock = threading.Lock()
known_clients = set()


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------

def get_now() -> datetime:
    return datetime.now(DK_TZ)


def clamp(value: float, minimum: float = MIN_SOC, maximum: float = MAX_SOC) -> float:
    return max(minimum, min(maximum, value))


def safe_float(value, default: float = 0.0) -> float:
    try:
        number = float(value)
        if math.isfinite(number):
            return number
        return default
    except (TypeError, ValueError):
        return default


def pad2(value: int) -> str:
    return str(value).zfill(2)


def slot_time_label(slot: int) -> str:
    slot = int(slot) % DEMO_SLOT_COUNT
    hour = slot // 4
    minute = (slot % 4) * 15
    return f"{pad2(hour)}:{pad2(minute)}"


def slot_interval_label(slot: int) -> str:
    start = slot_time_label(slot)
    end = slot_time_label((int(slot) + 1) % DEMO_SLOT_COUNT)
    return f"{start}-{end}"


def parse_status(raw: str) -> dict:
    """
    Parse key=value,key=value status string from the Arduino sketch.

    Example:
    panelVoltage=4.2,Batcurrent=0.013,PEMcurrent=-0.008,mode=S2
    """
    result = {}

    if not raw:
        return result

    for part in str(raw).split(","):
        if "=" not in part:
            continue

        key, value = part.split("=", 1)
        key = key.strip()
        value = value.strip()

        if key == "mode":
            result[key] = value
            continue

        try:
            if "." in value or "e" in value.lower():
                result[key] = float(value)
            else:
                result[key] = int(value)
        except ValueError:
            result[key] = value

    return result


def scenario_from_mode(mode: str) -> int:
    if not mode:
        return 0

    for n in SCENARIOS:
        if f"S{n}" in mode:
            return n

    return 0


# ---------------------------------------------------------------------------
# 96-step price and demand inputs
# ---------------------------------------------------------------------------

def load_demand_profile_from_csv(path: Path | str = DEMAND_PROFILE_PATH) -> list[float]:
    """
    Load the old 96-step consumption profile from CSV.

    Expected column: power_mW.
    Returned values are in W because the rest of the app uses W internally.
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Demand profile not found: {path}")

    values_w: list[float] = []

    with path.open("r", newline="", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)

        if not reader.fieldnames or "power_mW" not in reader.fieldnames:
            raise ValueError("Demand profile CSV must contain a 'power_mW' column.")

        for row in reader:
            power_mw = max(MIN_DEMAND_POWER_MW, safe_float(row.get("power_mW"), MIN_DEMAND_POWER_MW))
            values_w.append(round(power_mw / 1000.0, 5))

    if len(values_w) != DEMO_SLOT_COUNT:
        raise ValueError(f"Demand profile must contain exactly {DEMO_SLOT_COUNT} values, got {len(values_w)}.")

    return values_w


def make_default_demand_profile() -> list[float]:
    """Fallback only: flat 20 mW load if the CSV cannot be loaded."""
    return [round(MIN_DEMAND_POWER_MW / 1000.0, 5) for _ in range(DEMO_SLOT_COUNT)]

def _api_url(params: dict) -> str:
    return PRICE_API_URL + "?" + urlencode(params)


def _records_to_96_prices(records: list[dict], zone: str, selected_date: str) -> list[float]:
    """
    Convert Energi Data Service records to exactly 96 quarter-hour prices.

    Current API fields:
    - TimeDK
    - PriceArea
    - DayAheadPriceDKK in DKK/MWh

    Returned values are DKK/kWh.
    """
    zone = str(zone).upper()
    selected_date = str(selected_date)
    usable: list[tuple[str, float]] = []

    for record in records or []:
        if str(record.get("PriceArea", "")).upper() != zone:
            continue

        time_dk = str(record.get("TimeDK") or record.get("HourDK") or "")
        if selected_date and not time_dk.startswith(selected_date):
            continue

        raw_price = record.get("DayAheadPriceDKK")
        if raw_price is None:
            raw_price = record.get("SpotPriceDKK")
        if raw_price is None:
            raw_price = record.get("PriceDKK")

        price_dkk_per_mwh = safe_float(raw_price, None)
        if price_dkk_per_mwh is None or not time_dk:
            continue

        usable.append((time_dk, price_dkk_per_mwh / 1000.0))

    if not usable:
        raise ValueError(f"No usable DayAheadPriceDKK values returned for {zone} on {selected_date}")

    usable = sorted(usable, key=lambda item: item[0])

    # New API gives 15-minute prices: 96 records/day. Older API gave hourly
    # prices: repeat 24 records four times if needed.
    if len(usable) >= DEMO_SLOT_COUNT:
        return [round(float(price), 5) for _time, price in usable[:DEMO_SLOT_COUNT]]

    if len(usable) >= 24:
        hourly = [price for _time, price in usable[:24]]
        prices_96: list[float] = []
        for price in hourly:
            prices_96.extend([round(float(price), 5)] * 4)
        return prices_96[:DEMO_SLOT_COUNT]

    raise ValueError(f"Only got {len(usable)} price values for {zone} on {selected_date}, expected 96 or at least 24")


def fetch_day_ahead_prices(zone: str = "DK2", selected_date: str | None = None) -> list[float]:
    """Fetch selected-date day-ahead prices from Energi Data Service."""
    zone = str(zone or "DK2").upper()
    if zone not in VALID_PRICE_ZONES:
        zone = "DK2"

    if not selected_date:
        selected_date = get_now().date().isoformat()

    day = datetime.strptime(selected_date, "%Y-%m-%d").replace(tzinfo=DK_TZ)
    start = day.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=1)

    params = {
        "start": start.strftime("%Y-%m-%dT%H:%M"),
        "end": end.strftime("%Y-%m-%dT%H:%M"),
        "filter": json.dumps({"PriceArea": [zone]}),
        "sort": "TimeDK",
        "timezone": "dk",
        "limit": "200",
    }

    url = _api_url(params)
    print(f"Fetching prices for {selected_date} from: {url}")

    with urlopen(url, timeout=PRICE_REQUEST_TIMEOUT) as response:
        payload = json.loads(response.read().decode("utf-8"))

    records = payload.get("records", [])
    if not records:
        raise ValueError(f"No records returned for {zone} on {selected_date}")

    prices = _records_to_96_prices(records, zone, selected_date)
    print(f"Loaded {len(prices)} API price values for {zone} on {selected_date}")
    print(f"First prices: {prices[:8]}")
    return prices


def refresh_prices() -> None:
    try:
        prices = fetch_day_ahead_prices(state.price_zone, state.price_date)
        state.prices = prices
        state.last_price_update = get_now().isoformat(timespec="seconds")
        state.price_source = f"{PRICE_SOURCE} ({state.price_zone}, {state.price_date})"
        state.last_error = ""

    except Exception as exc:
        # Important: do not generate a fake price curve. If the API fails, keep
        # prices empty so the plot clearly shows no API price data.
        state.prices = []
        state.last_price_update = get_now().isoformat(timespec="seconds")
        state.price_source = f"{PRICE_SOURCE} failed"
        state.last_error = f"Price API failed; no fallback curve is used: {exc}"
        print(state.last_error)

    update_price_threshold()

def refresh_demand_profile() -> None:
    try:
        state.demand_profile = load_demand_profile_from_csv()
        state.last_demand_update = get_now().isoformat(timespec="seconds")
        print(f"Loaded {len(state.demand_profile)} demand values from {DEMAND_PROFILE_PATH}")
    except Exception as exc:
        state.demand_profile = make_default_demand_profile()
        state.last_demand_update = get_now().isoformat(timespec="seconds")
        state.last_error = f"Demand CSV failed, using flat fallback: {exc}"
        print(state.last_error)

def update_price_threshold() -> None:
    prices = state.prices or []
    valid = sorted(p for p in prices if isinstance(p, (int, float)) and math.isfinite(float(p)))

    if not valid:
        state.price_threshold = 0.0
        return

    # 65th percentile threshold: highest roughly 35% of the day is HIGH.
    index = int(len(valid) * 0.65)
    index = max(0, min(index, len(valid) - 1))
    state.price_threshold = float(valid[index])


def price_state_for_slot(slot: int) -> str:
    prices = state.prices or []
    if slot < 0 or slot >= len(prices) or prices[slot] is None:
        return state.price_state

    price = safe_float(prices[slot], 0.0)
    threshold = safe_float(state.price_threshold, 0.0)
    return "HIGH" if price >= threshold else "LOW"


def update_demo_slot() -> None:
    if state.simulation_running:
        elapsed = max(0.0, time.time() - state.demo_start_time)
        absolute_slot = int(elapsed / DEMO_SLOT_SECONDS)
        state.demo_cycle = absolute_slot // DEMO_SLOT_COUNT
        state.current_slot = absolute_slot % DEMO_SLOT_COUNT

    state.current_time_label = slot_time_label(state.current_slot)
    state.current_interval_label = slot_interval_label(state.current_slot)


def update_current_timeline_inputs() -> None:
    slot = state.current_slot

    if state.prices and slot < len(state.prices) and state.prices[slot] is not None:
        state.current_price = safe_float(state.prices[slot], 0.0)
    else:
        state.current_price = 0.0

    if state.demand_profile and slot < len(state.demand_profile):
        state.current_demand_w = safe_float(state.demand_profile[slot], 0.0)
    else:
        state.current_demand_w = 0.0

    if state.price_mode == "api":
        state.price_state = price_state_for_slot(slot)


# ---------------------------------------------------------------------------
# Arduino bridge communication
# ---------------------------------------------------------------------------

def fetch_arduino_status() -> dict:
    raw = Bridge.call("get_status", timeout=BRIDGE_TIMEOUT)
    return parse_status(raw)


def send_scenario_to_arduino(scenario: int) -> None:
    scenario = int(scenario)

    if scenario not in SCENARIOS:
        scenario = 1

    Bridge.call(
        "apply_scenario_frame",
        f"SCENARIO,{scenario}",
        timeout=BRIDGE_TIMEOUT,
    )


def send_relay_to_arduino(relay: str, output_state: int) -> None:
    relay = str(relay).upper()
    value = 1 if int(output_state) else 0

    Bridge.call(
        "apply_relay_frame",
        f"RELAY,{relay},{value}",
        timeout=BRIDGE_TIMEOUT,
    )



def send_load_trigger_to_arduino(active: bool) -> None:
    value = 1 if active else 0

    Bridge.call(
        "apply_load_trigger_frame",
        f"LOAD_TRIGGER,{value}",
        timeout=BRIDGE_TIMEOUT,
    )


# ---------------------------------------------------------------------------
# SoC integration
# ---------------------------------------------------------------------------

def integrate_soc(
    current_a: float,
    dt_seconds: float,
    current_soc: float,
    charge_capacity_mah: float,
    discharge_capacity_mah: float,
) -> float:
    """
    Integrate current into SoC.

    Sign convention:
    positive current = charging
    negative current = discharging
    """
    if dt_seconds <= 0:
        return current_soc

    current_ma = current_a * 1000.0
    dt_hours = dt_seconds / 3600.0
    delta_mah = current_ma * dt_hours

    if delta_mah >= 0:
        delta_soc = (delta_mah / charge_capacity_mah) * 100.0
    else:
        delta_soc = (delta_mah / discharge_capacity_mah) * 100.0

    return clamp(current_soc + delta_soc)


def update_virtual_socs_from_current(arduino_status: dict | None) -> None:
    global last_soc_update_time

    now = time.time()
    dt_seconds = now - last_soc_update_time
    last_soc_update_time = now

    if not arduino_status:
        return

    if dt_seconds <= 0 or dt_seconds > MAX_SOC_INTEGRATION_DT_SECONDS:
        return

    battery_current = safe_float(arduino_status.get("Batcurrent", 0.0), 0.0)
    pem_current = safe_float(arduino_status.get("PEMcurrent", 0.0), 0.0)

    state.battery_soc = integrate_soc(
        current_a=battery_current,
        dt_seconds=dt_seconds,
        current_soc=state.battery_soc,
        charge_capacity_mah=BATTERY_CAPACITY_MAH,
        discharge_capacity_mah=BATTERY_CAPACITY_MAH,
    )

    update_hydrogen_from_current(pem_current, dt_seconds)


def h2_usable_range_mL() -> float:
    return H2_MAX_ML - H2_MIN_USABLE_ML


def h2_volume_from_soc(soc_percent: float) -> float:
    soc_fraction = clamp(float(soc_percent), 0.0, 100.0) / 100.0
    return H2_MIN_USABLE_ML + soc_fraction * h2_usable_range_mL()


def h2_soc_from_volume(h2_volume_mL: float) -> float:
    usable_range = h2_usable_range_mL()

    if usable_range <= 0:
        return 0.0

    soc_percent = ((h2_volume_mL - H2_MIN_USABLE_ML) / usable_range) * 100.0
    return clamp(soc_percent, 0.0, 100.0)


def sync_hydrogen_state() -> None:
    state.h2_volume_mL = clamp(state.h2_volume_mL, H2_MIN_USABLE_ML, H2_MAX_ML)
    state.h2_usable_mL = max(0.0, state.h2_volume_mL - H2_MIN_USABLE_ML)
    state.h2_usable_soc = h2_soc_from_volume(state.h2_volume_mL)
    state.pem_soc = state.h2_usable_soc


def update_hydrogen_from_current(pem_current_a: float, dt_seconds: float) -> None:
    if dt_seconds <= 0:
        return

    old_volume = state.h2_volume_mL
    delta_mL = 0.0

    if pem_current_a > PEM_CHARGE_CURRENT_THRESHOLD_A:
        charge_coulomb = pem_current_a * dt_seconds
        delta_mL = charge_coulomb * H2_CHARGE_ML_PER_C
        state.h2_mode = "charging"
    elif pem_current_a < PEM_DISCHARGE_CURRENT_THRESHOLD_A:
        discharge_coulomb = abs(pem_current_a) * dt_seconds
        delta_mL = -discharge_coulomb * H2_DISCHARGE_ML_PER_C
        state.h2_mode = "discharging"
    else:
        state.h2_mode = "idle"

    state.h2_volume_mL = old_volume + delta_mL
    sync_hydrogen_state()
    state.h2_last_delta_mL = state.h2_volume_mL - old_volume


def set_hydrogen_soc(soc_percent: float) -> None:
    state.pem_soc = clamp(float(soc_percent), 0.0, 100.0)
    state.h2_volume_mL = h2_volume_from_soc(state.pem_soc)
    sync_hydrogen_state()


def reset_soc_initial_condition(battery_soc: float, pem_soc: float) -> None:
    global last_soc_update_time

    state.battery_soc = clamp(float(battery_soc))
    set_hydrogen_soc(float(pem_soc))
    last_soc_update_time = time.time()


# ---------------------------------------------------------------------------
# PV availability latch
# ---------------------------------------------------------------------------

def measured_pv_initially_available(status: dict | None) -> bool:
    if not status:
        return False

    panel_voltage = safe_float(status.get("panelVoltage", 0.0), 0.0)
    return panel_voltage > PV_AVAILABLE_VOLTAGE


def measured_pv_power_too_low(status: dict | None) -> bool:
    if not status:
        return True

    pv_power = safe_float(status.get("PVpower", 0.0), 0.0)
    return pv_power < PV_MIN_POWER_W


def update_pv_latch() -> None:
    """PV latch with 1 second low-power delay before unlatching."""
    now = time.monotonic()

    if state.pv_mode == "force_available":
        state.pv_latched_available = True
        state.pv_low_power_since = None
        return

    if state.pv_mode == "force_unavailable":
        state.pv_latched_available = False
        state.pv_low_power_since = None
        return

    if not state.pv_latched_available:
        if measured_pv_initially_available(state.arduino_status):
            state.pv_latched_available = True
            state.pv_low_power_since = None
        return

    if measured_pv_power_too_low(state.arduino_status):
        if state.pv_low_power_since is None:
            state.pv_low_power_since = now
            return

        if now - state.pv_low_power_since >= PV_LATCH_OFF_DELAY_SECONDS:
            state.pv_latched_available = False
            state.pv_low_power_since = None
    else:
        state.pv_low_power_since = None


def pv_available_from_state() -> bool:
    return state.pv_latched_available


# ---------------------------------------------------------------------------
# Scenario decision and optional timeline flow model
# ---------------------------------------------------------------------------

def decide_scenario_for_inputs(price_state: str, pv_available: bool, battery_soc: float, pem_soc: float) -> tuple[int, str]:
    price_high = str(price_state).upper() == "HIGH"

    if not price_high:
        if not pv_available:
            return 1, "LOW price and PV unavailable -> S1."

        if battery_soc > 90.0:
            return 3, "LOW price, PV available, battery SoC > 90% -> S3."

        return 2, "LOW price, PV available, battery SoC <= 90% -> S2."

    if pv_available:
        return 4, "HIGH price and PV available -> S4."

    if battery_soc > 10.0:
        return 5, "HIGH price, PV unavailable, battery SoC > 10% -> S5."

    if pem_soc > 10.0:
        return 6, "HIGH price, PV unavailable, battery SoC <= 10%, PEM SoC > 10% -> S6."

    return 1, "HIGH price, PV unavailable, battery SoC <= 10%, PEM SoC <= 10% -> S1."


def decide_scenario() -> tuple[int, str]:
    return decide_scenario_for_inputs(
        price_state=state.price_state,
        pv_available=pv_available_from_state(),
        battery_soc=state.battery_soc,
        pem_soc=state.pem_soc,
    )


def current_pv_power_estimate_w() -> float:
    status = state.arduino_status or {}
    measured = safe_float(status.get("PVpower", 0.0), 0.0)

    if measured >= PV_MIN_POWER_W:
        return measured

    if pv_available_from_state():
        # Use a small but visible charging value for the future plot if PV is
        # latched available but the current measured PV power is momentarily low.
        return max(PV_MIN_POWER_W, 0.030)

    return 0.0


def flow_for_scenario(scenario: int, demand_w: float, pv_charge_power_w: float) -> dict:
    """
    Return component power flows for one slot.

    Sign convention for storage components in the plot:
    - positive battery/pem = discharging to load
    - negative battery/pem = charging
    """
    demand_w = max(0.0, safe_float(demand_w, 0.0))
    pv_charge_power_w = max(0.0, safe_float(pv_charge_power_w, 0.0))

    flow = {
        "grid_w": 0.0,
        "pv_w": 0.0,
        "battery_w": 0.0,
        "pem_w": 0.0,
        "load_w": demand_w,
    }

    if scenario == 1:
        flow["grid_w"] = demand_w
    elif scenario == 2:
        flow["grid_w"] = demand_w
        flow["pv_w"] = pv_charge_power_w
        flow["battery_w"] = -pv_charge_power_w
    elif scenario == 3:
        flow["grid_w"] = demand_w
        flow["pv_w"] = pv_charge_power_w
        flow["pem_w"] = -pv_charge_power_w
    elif scenario == 4:
        flow["pv_w"] = demand_w
    elif scenario == 5:
        flow["battery_w"] = demand_w
    elif scenario == 6:
        flow["pem_w"] = demand_w
    else:
        flow["grid_w"] = demand_w

    return flow


def build_timeline() -> dict:
    # Prices are API-only. If the API failed, keep missing future price values as
    # None so the WebUI does not draw a misleading/generated price curve.
    raw_prices = list(state.prices or [])[:DEMO_SLOT_COUNT]
    prices: list[float | None] = [round(float(p), 5) for p in raw_prices if isinstance(p, (int, float)) and math.isfinite(float(p))]

    while len(prices) < DEMO_SLOT_COUNT:
        prices.append(None)

    demand = list(state.demand_profile or make_default_demand_profile())[:DEMO_SLOT_COUNT]

    while len(demand) < DEMO_SLOT_COUNT:
        demand.append(demand[-1] if demand else 0.02)

    pv_available = pv_available_from_state()
    pv_charge_power_w = current_pv_power_estimate_w()

    price_states = []
    scenarios = []
    grid_w = []
    pv_w = []
    battery_w = []
    pem_w = []
    load_w = []
    labels = []

    for slot in range(DEMO_SLOT_COUNT):
        slot_price_state = price_state_for_slot(slot) if state.price_mode == "api" else state.price_state
        scenario, _reason = decide_scenario_for_inputs(
            price_state=slot_price_state,
            pv_available=pv_available,
            battery_soc=state.battery_soc,
            pem_soc=state.pem_soc,
        )
        flow = flow_for_scenario(scenario, demand[slot], pv_charge_power_w)

        price_states.append(slot_price_state)
        scenarios.append(scenario)
        grid_w.append(round(flow["grid_w"], 5))
        pv_w.append(round(flow["pv_w"], 5))
        battery_w.append(round(flow["battery_w"], 5))
        pem_w.append(round(flow["pem_w"], 5))
        load_w.append(round(flow["load_w"], 5))
        labels.append(slot_time_label(slot))

    return {
        "slot_count": DEMO_SLOT_COUNT,
        "current_slot": state.current_slot,
        "labels": labels,
        "prices": prices,
        "price_states": price_states,
        "demand_w": demand,
        "scenarios": scenarios,
        "flows": {
            "grid_w": grid_w,
            "pv_w": pv_w,
            "battery_w": battery_w,
            "pem_w": pem_w,
            "load_w": load_w,
        },
        "units": {
            "power": "W",
            "price": "DKK/kWh",
        },
    }


def _new_live_history() -> dict:
    return {
        "cycle": state.demo_cycle,
        "pv_w": [None] * DEMO_SLOT_COUNT,
        "battery_w": [None] * DEMO_SLOT_COUNT,
        "pem_w": [None] * DEMO_SLOT_COUNT,
        "load_w": [None] * DEMO_SLOT_COUNT,
        "grid_w": [None] * DEMO_SLOT_COUNT,
        "scenario": [None] * DEMO_SLOT_COUNT,
    }


def update_live_history() -> None:
    """Store actual INA sensor readings at the current 96-step slot."""
    status = state.arduino_status or {}
    slot = max(0, min(DEMO_SLOT_COUNT - 1, int(state.current_slot)))

    if state.live_history is None or state.live_history.get("cycle") != state.demo_cycle:
        state.live_history = _new_live_history()

    pv_w = safe_float(status.get("PVpower"), 0.0)
    battery_w = safe_float(status.get("Batterypower"), 0.0)
    pem_w = safe_float(status.get("PEMpower"), 0.0)
    load_w = safe_float(status.get("Loadpower"), 0.0)

    scenario = state.actual_scenario or state.target_scenario

    # Grid is not measured by an INA sensor, so estimate it when the scenario
    # indicates grid supply to the load.
    grid_w = load_w if scenario in {1, 2, 3} else 0.0

    state.live_history["pv_w"][slot] = round(pv_w, 5)
    state.live_history["battery_w"][slot] = round(battery_w, 5)
    state.live_history["pem_w"][slot] = round(pem_w, 5)
    state.live_history["load_w"][slot] = round(load_w, 5)
    state.live_history["grid_w"][slot] = round(grid_w, 5)
    state.live_history["scenario"][slot] = scenario


def update_timeline() -> None:
    state.timeline = build_timeline()


# ---------------------------------------------------------------------------
# State update and publishing
# ---------------------------------------------------------------------------

def refresh_status() -> None:
    try:
        status = fetch_arduino_status()

        state.arduino_status = status
        state.actual_scenario = scenario_from_mode(str(status.get("mode", ""))) or state.target_scenario
        state.bridge_ok = True
        state.last_error = ""

        if state.simulation_running:
            update_virtual_socs_from_current(status)
        update_pv_latch()
        if state.simulation_running:
            update_live_history()

    except Exception as exc:
        state.bridge_ok = False
        state.last_error = f"Bridge error: {exc}"


def apply_target_scenario(scenario: int, reason: str) -> None:
    scenario = int(scenario)

    if scenario not in SCENARIOS:
        scenario = 1

    state.target_scenario = scenario
    state.reason = reason

    try:
        send_scenario_to_arduino(scenario)
        refresh_status()

    except Exception as exc:
        state.bridge_ok = False
        state.last_error = f"Bridge error: {exc}"


def update_runtime_inputs() -> None:
    update_demo_slot()
    update_current_timeline_inputs()
    update_timeline()


def build_payload() -> dict:
    payload = asdict(state)
    payload["scenarios"] = SCENARIOS
    payload["pv_available"] = pv_available_from_state()
    payload["pv_threshold_v"] = PV_AVAILABLE_VOLTAGE
    payload["pv_min_power_w"] = PV_MIN_POWER_W

    payload["battery_capacity_mah"] = BATTERY_CAPACITY_MAH
    payload["pem_discharge_capacity_mah"] = PEM_DISCHARGE_CAPACITY_MAH
    payload["pem_charge_capacity_mah"] = PEM_CHARGE_CAPACITY_MAH
    payload["h2_min_usable_mL"] = H2_MIN_USABLE_ML
    payload["h2_max_mL"] = H2_MAX_ML

    payload["valid_price_zones"] = VALID_PRICE_ZONES
    payload["demo_slot_seconds"] = DEMO_SLOT_SECONDS
    payload["price_threshold_rule"] = "65th percentile of selected day prices; highest ~35% = HIGH"

    return payload


def publish() -> None:
    with state_lock:
        payload = build_payload()

    ui.send_message("telemetry", payload)


def api_status():
    with state_lock:
        return build_payload()


# ---------------------------------------------------------------------------
# Main control loop
# ---------------------------------------------------------------------------

def control_loop() -> None:
    while True:
        with state_lock:
            update_runtime_inputs()
            refresh_status()
            update_runtime_inputs()

            if state.simulation_running and state.control_mode == "auto":
                scenario, reason = decide_scenario()

                if scenario != state.target_scenario:
                    apply_target_scenario(scenario, reason)
                else:
                    state.reason = reason

            if state.simulation_running and state.logging_enabled:
                logger.log(state)
                state.last_log_update = get_now().isoformat(timespec="seconds")

            update_timeline()

        publish()
        time.sleep(LOOP_SECONDS)


# ---------------------------------------------------------------------------
# WebUI event handlers
# ---------------------------------------------------------------------------

def on_state_request(client_id, data):
    known_clients.add(client_id)
    publish()


def on_control(client_id, data):
    known_clients.add(client_id)

    data = data or {}
    action = data.get("action", "")

    with state_lock:
        update_runtime_inputs()

        if action == "refresh":
            refresh_prices()
            refresh_demand_profile()
            refresh_status()
            update_runtime_inputs()

        elif action == "restart_demo":
            state.demo_start_time = time.time()
            state.demo_cycle = 0
            state.current_slot = 0
            state.live_history = None
            update_runtime_inputs()
            state.reason = "Timeline reset to slot 0. Press Start simulation to advance and log."

        elif action == "start_simulation":
            state.simulation_running = True
            state.logging_enabled = True
            state.demo_start_time = time.time()
            state.demo_cycle = 0
            state.current_slot = 0
            state.live_history = _new_live_history()
            reset_soc_initial_condition(state.battery_soc, state.pem_soc)
            state.log_file = logger.start()
            state.last_log_update = get_now().isoformat(timespec="seconds")

            try:
                send_load_trigger_to_arduino(True)
                state.reason = "Simulation and CSV logging started from WebUI. Load sequence trigger D10 set HIGH."
            except Exception as exc:
                state.bridge_ok = False
                state.last_error = f"Could not set load trigger HIGH: {exc}"
                state.reason = "Simulation started, but load sequence trigger could not be set HIGH."

            update_runtime_inputs()

        elif action == "stop_simulation":
            state.simulation_running = False
            state.logging_enabled = False
            logger.stop()

            try:
                send_load_trigger_to_arduino(False)
                state.reason = "Simulation and CSV logging stopped from WebUI. Load sequence trigger D10 set LOW."
            except Exception as exc:
                state.bridge_ok = False
                state.last_error = f"Could not set load trigger LOW: {exc}"
                state.reason = "Simulation stopped, but load sequence trigger could not be set LOW."

            update_runtime_inputs()

        elif action == "reset_simulation":
            state.simulation_running = False
            state.logging_enabled = False
            logger.stop()
            state.demo_start_time = time.time()
            state.demo_cycle = 0
            state.current_slot = 0
            state.live_history = None
            state.last_log_update = ""

            try:
                send_load_trigger_to_arduino(False)
                state.reason = "Simulation reset. Load sequence trigger D10 set LOW. Press Start simulation to begin."
            except Exception as exc:
                state.bridge_ok = False
                state.last_error = f"Could not set load trigger LOW: {exc}"
                state.reason = "Simulation reset, but load sequence trigger could not be set LOW."

            update_runtime_inputs()

        elif action == "set_mode":
            state.control_mode = "auto" if data.get("mode") == "auto" else "manual"

            if state.control_mode == "auto" and state.simulation_running:
                refresh_status()
                update_runtime_inputs()
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)
            elif state.control_mode == "auto":
                state.reason = "Automatic mode selected. Press Start simulation + logging to begin scheduling."
            else:
                state.reason = "Manual mode enabled. Automatic scenario changes are disabled."

        elif action == "set_price_mode":
            value = data.get("price_mode", "api")
            state.price_mode = "manual" if value == "manual" else "api"
            update_runtime_inputs()

            if state.control_mode == "auto" and state.simulation_running:
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "set_price_state":
            state.price_state = "HIGH" if data.get("price_state") == "HIGH" else "LOW"

            if state.price_mode == "api":
                # Manual price input is only used when price mode is manual.
                update_current_timeline_inputs()

            if state.control_mode == "auto" and state.simulation_running:
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "set_price_date":
            value = str(data.get("price_date", state.price_date)).strip()
            try:
                datetime.strptime(value, "%Y-%m-%d")
                state.price_date = value
                refresh_prices()
                update_runtime_inputs()
            except Exception as exc:
                state.last_error = f"Invalid price date or API error: {exc}"

            if state.control_mode == "auto" and state.simulation_running:
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "set_price_zone":
            zone = str(data.get("price_zone", state.price_zone)).upper()
            if zone in VALID_PRICE_ZONES:
                state.price_zone = zone
                refresh_prices()
                update_runtime_inputs()
            else:
                state.last_error = "Invalid price zone. Use DK1 or DK2."

            if state.control_mode == "auto" and state.simulation_running:
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "set_pv_mode":
            value = data.get("pv_mode", "auto")

            if value in {"auto", "force_available", "force_unavailable"}:
                state.pv_mode = value
            else:
                state.pv_mode = "auto"

            update_pv_latch()
            update_timeline()

            if state.control_mode == "auto" and state.simulation_running:
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "set_soc":
            try:
                battery_soc = data.get("battery_soc", state.battery_soc)
                pem_soc = data.get("pem_soc", state.pem_soc)

                reset_soc_initial_condition(
                    battery_soc=safe_float(battery_soc, state.battery_soc),
                    pem_soc=safe_float(pem_soc, state.pem_soc),
                )

                state.reason = (
                    "Manual SoC input applied as new initial condition. "
                    "Current integration continues from this value."
                )

            except (TypeError, ValueError):
                state.last_error = "Invalid SoC input."

            update_timeline()

            if state.control_mode == "auto" and state.simulation_running:
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "manual_scenario":
            try:
                scenario = int(data.get("scenario", 1))
            except (TypeError, ValueError):
                scenario = 1

            state.control_mode = "manual"
            apply_target_scenario(scenario, f"Manual scenario command -> S{scenario}.")

        elif action == "set_relay":
            relay = str(data.get("relay", "")).upper()

            try:
                output_state = 1 if int(data.get("state", 0)) else 0
            except (TypeError, ValueError):
                output_state = 0

            if relay not in {"K1", "K2", "K3", "K4", "K5", "K6", "K7"}:
                state.last_error = "Invalid relay name."

            else:
                state.control_mode = "manual"

                try:
                    send_relay_to_arduino(relay, output_state)
                    refresh_status()
                    state.reason = f"Manual relay command: {relay} = {output_state}."

                except Exception as exc:
                    state.bridge_ok = False
                    state.last_error = f"Bridge error: {exc}"

        update_runtime_inputs()

    publish()


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------

def setup_ui() -> None:
    ui.expose_api("GET", "/api/status", api_status)
    ui.on_message("state_request", on_state_request)
    ui.on_message("control", on_control)


with state_lock:
    state.price_date = get_now().date().isoformat()
    refresh_demand_profile()
    refresh_prices()
    update_runtime_inputs()

setup_ui()

threading.Thread(target=control_loop, daemon=True).start()

print("Starting simplified EMS app with API prices, demand timeline, INA moving log and hydrogen estimator...")

App.run()
