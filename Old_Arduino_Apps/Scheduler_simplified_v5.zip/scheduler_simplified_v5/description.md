# Simplified EMS Scheduler with date-selected prices and logger

This version keeps the simplified six-scenario scheduler and WebUI, and adds:

- Date selector for Energi Data Service day-ahead prices.
- API parser for the current `DayAheadPrices` fields: `TimeDK`, `PriceArea`, `DayAheadPriceDKK`.
- No generated/fake price curve. If the API fails, the price line is absent and the WebUI shows the error.
- 96-step demand profile from `python/data/variable_load_signal/scaled_may_power_profile_15min.csv`.
- Moving INA log timeline: future demand/prices are shown, but INA component traces only appear when measurements have actually been logged.
- CSV logger in `python/logger.py`.
- Simulation, moving INA log, automatic scheduling, and CSV logging only start after pressing **Start simulation + logging** in the WebUI.
- PV latch-off debounce: PV must remain below 10 mW for 1 second before unlatching.
- Hydrogen estimator and current-integrated Battery/PEM state.

The logger writes CSV files to `logs/` inside the app folder.
