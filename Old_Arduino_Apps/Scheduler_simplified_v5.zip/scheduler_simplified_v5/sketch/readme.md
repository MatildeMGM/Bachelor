# Simplified sketch

This sketch only does the basic Arduino work:

- reads INA226 values;
- applies Scenario 1-6 relay states;
- exposes `apply_scenario_frame`, `apply_relay_frame`, and `get_status` to Python through `Arduino_RouterBridge`;
- does not include Scenario 7/8;
- does not reject scenarios with old automatic safety thresholds.

The automatic decision logic is in `python/main.py`.
