#include <Arduino_RouterBridge.h>
#include <Wire.h>
#include <INA226_WE.h>

#define ADDR_BAT  0x40
#define ADDR_LOAD 0x41
#define ADDR_PV   0x44
#define ADDR_PEM  0x45

INA226_WE inaBat(&Wire, ADDR_BAT);
INA226_WE inaLoad(&Wire, ADDR_LOAD);
INA226_WE inaPV(&Wire, ADDR_PV);
INA226_WE inaPEM(&Wire, ADDR_PEM);

// Relay pins
const int K1 = 8;
const int K2 = 2;
const int K3 = 3;
const int K4 = 4;
const int K5 = 5;
const int K6 = 7;
const int K7 = 9;

// Load sequence trigger output
const int LOAD_SEQUENCE_TRIGGER_PIN = 10;

// Scenario LEDs
const int LEDS1 = 12;
const int LEDS2 = 0;
const int LEDS3 = 11;
const int LEDS4 = 6;
const int LEDS5 = 1;
const int LEDS6 = 13;

bool inaBatOk = false;
bool inaLoadOk = false;
bool inaPVOk = false;
bool inaPEMOk = false;

float panelVoltage = 0.0;
float batteryVoltage = 0.0;
float pemrfcVoltage = 0.0;
float loadVoltage = 0.0;

float PVcurrent = 0.0;
float Batcurrent = 0.0;
float PEMcurrent = 0.0;
float Loadcurrent = 0.0;

float PVshuntVoltage_mV = 0.0;
float BatshuntVoltage_mV = 0.0;
float PEMshuntVoltage_mV = 0.0;
float LoadshuntVoltage_mV = 0.0;

float PVpower = 0.0;
float Batterypower = 0.0;
float PEMpower = 0.0;
float Loadpower = 0.0;

int requestedScenario = 1;
bool scenarioReceived = false;
String mode = "S1 Grid -> Load";
String lastError = "";

unsigned long lastPrint = 0;
const long printInterval = 2000;

bool setupINA(INA226_WE &sensor, const char* name);
float correctCurrent_A(byte address, float current_A);
float correctVoltage_V(byte address, float voltage_V);
void readMeasurements();
void printValues();
void setLoadSequenceTrigger(bool active);
void applyScenario(int scenario);
void setScenarioLeds(int scenario);
void allScenarioLedsOff();
int relayPinFromName(String relayName);

bool apply_scenario_frame(String payload);
bool apply_relay_frame(String payload);
bool apply_load_trigger_frame(String payload);
String get_status();

void setup() {
  Monitor.begin();
  delay(1000);
  Monitor.println("Simplified EMS sketch started");

  Bridge.begin();
  Bridge.provide("apply_scenario_frame", apply_scenario_frame);
  Bridge.provide("apply_relay_frame", apply_relay_frame);
  Bridge.provide("apply_load_trigger_frame", apply_load_trigger_frame);
  Bridge.provide("get_status", get_status);

  Wire.begin();
  delay(500);

  inaBatOk = setupINA(inaBat, "INA226 Battery");
  inaLoadOk = setupINA(inaLoad, "INA226 Load");
  inaPVOk = setupINA(inaPV, "INA226 PV");
  inaPEMOk = setupINA(inaPEM, "INA226 PEMRFC");

  pinMode(K1, OUTPUT);
  pinMode(K2, OUTPUT);
  pinMode(K3, OUTPUT);
  pinMode(K4, OUTPUT);
  pinMode(K5, OUTPUT);
  pinMode(K6, OUTPUT);
  pinMode(K7, OUTPUT);

  pinMode(LOAD_SEQUENCE_TRIGGER_PIN, OUTPUT);
  digitalWrite(LOAD_SEQUENCE_TRIGGER_PIN, LOW);

  pinMode(LEDS1, OUTPUT);
  pinMode(LEDS2, OUTPUT);
  pinMode(LEDS3, OUTPUT);
  pinMode(LEDS4, OUTPUT);
  pinMode(LEDS5, OUTPUT);
  pinMode(LEDS6, OUTPUT);

  applyScenario(1);
}

void loop() {
  readMeasurements();

  if (millis() - lastPrint >= printInterval) {
    lastPrint = millis();
    printValues();
  }

  delay(400);
}

bool setupINA(INA226_WE &sensor, const char* name) {
  Monitor.print("Initializing ");
  Monitor.print(name);
  Monitor.print(" ... ");

  if (!sensor.init()) {
    Monitor.println("FAILED");
    return false;
  }

  sensor.setAverage(INA226_AVERAGE_16);
  sensor.setConversionTime(INA226_CONV_TIME_1100);
  sensor.setMeasureMode(INA226_CONTINUOUS);
  sensor.waitUntilConversionCompleted();

  Monitor.println("OK");
  return true;
}

float correctCurrent_A(byte address, float current_A) {
  // Software correction factors from calibration.
  // Positive current must still mean charging for Battery and PEM.
  switch (address) {
    case ADDR_BAT:  return current_A + 0.000563;
    case ADDR_LOAD: return current_A - 0.000033;
    case ADDR_PV:   return current_A + 0.000138;
    case ADDR_PEM:  return 0.843 * current_A + 0.001;
    default:        return current_A;
  }
}

float correctVoltage_V(byte address, float voltage_V) {
  // Software voltage offsets from calibration.
  switch (address) {
    case ADDR_BAT:  return voltage_V - 0.068;
    case ADDR_LOAD: return voltage_V - 0.066;
    case ADDR_PV:   return voltage_V - 0.180;
    case ADDR_PEM:  return voltage_V - 0.064;
    default:        return voltage_V;
  }
}


void setLoadSequenceTrigger(bool active) {
  digitalWrite(LOAD_SEQUENCE_TRIGGER_PIN, active ? HIGH : LOW);
}

bool apply_scenario_frame(String payload) {
  // Expected compact format from python/main.py:
  //   SCENARIO,<scenario>
  // Also accepts old format:
  //   SCENARIO,<slot>,<scenario>,<demand_mW>
  if (!payload.startsWith("SCENARIO,") && !payload.startsWith("MANUAL_SCENARIO,")) {
    lastError = "invalid scenario frame";
    return false;
  }

  int c1 = payload.indexOf(',');
  int c2 = payload.indexOf(',', c1 + 1);
  int c3 = payload.indexOf(',', c2 + 1);

  int scenario = 1;
  if (c2 < 0) {
    scenario = payload.substring(c1 + 1).toInt();
  } else if (c3 >= 0) {
    scenario = payload.substring(c2 + 1, c3).toInt();
  } else {
    scenario = payload.substring(c1 + 1, c2).toInt();
  }

  if (scenario < 1 || scenario > 6) {
    lastError = "scenario must be 1-6";
    return false;
  }

  requestedScenario = scenario;
  scenarioReceived = true;
  lastError = "";
  applyScenario(scenario);

  Monitor.print("Applied scenario S");
  Monitor.println(scenario);
  return true;
}

bool apply_relay_frame(String payload) {
  // Expected format: RELAY,<K1-K7>,<0-or-1>
  if (!payload.startsWith("RELAY,")) {
    lastError = "invalid relay frame";
    return false;
  }

  int c1 = payload.indexOf(',');
  int c2 = payload.indexOf(',', c1 + 1);
  if (c1 < 0 || c2 < 0) {
    lastError = "invalid relay commas";
    return false;
  }

  String relayName = payload.substring(c1 + 1, c2);
  relayName.trim();
  relayName.toUpperCase();

  int pin = relayPinFromName(relayName);
  if (pin < 0) {
    lastError = "unknown relay";
    return false;
  }

  int outputState = payload.substring(c2 + 1).toInt() ? HIGH : LOW;
  digitalWrite(pin, outputState);
  allScenarioLedsOff();

  mode = "Manual relay " + relayName + (outputState == HIGH ? " HIGH" : " LOW");
  lastError = "";
  return true;
}


bool apply_load_trigger_frame(String payload) {
  // Expected format: LOAD_TRIGGER,<0-or-1>
  if (!payload.startsWith("LOAD_TRIGGER,")) {
    lastError = "invalid load trigger frame";
    return false;
  }

  int c1 = payload.indexOf(',');
  if (c1 < 0) {
    lastError = "invalid load trigger commas";
    return false;
  }

  int value = payload.substring(c1 + 1).toInt();
  setLoadSequenceTrigger(value == 1);
  lastError = "";

  Monitor.print("Load sequence trigger D10 ");
  Monitor.println(value == 1 ? "HIGH" : "LOW");

  return true;
}

String get_status() {
  String payload = "";

  payload += "inaBatOk=" + String(inaBatOk ? 1 : 0);
  payload += ",inaLoadOk=" + String(inaLoadOk ? 1 : 0);
  payload += ",inaPVOk=" + String(inaPVOk ? 1 : 0);
  payload += ",inaPEMOk=" + String(inaPEMOk ? 1 : 0);

  payload += ",panelVoltage=" + String(panelVoltage, 5);
  payload += ",batteryVoltage=" + String(batteryVoltage, 5);
  payload += ",pemrfcVoltage=" + String(pemrfcVoltage, 5);
  payload += ",loadVoltage=" + String(loadVoltage, 5);

  payload += ",PVcurrent=" + String(PVcurrent, 5);
  payload += ",Batcurrent=" + String(Batcurrent, 5);
  payload += ",PEMcurrent=" + String(PEMcurrent, 5);
  payload += ",Loadcurrent=" + String(Loadcurrent, 5);

  payload += ",PVshunt_mV=" + String(PVshuntVoltage_mV, 5);
  payload += ",Batshunt_mV=" + String(BatshuntVoltage_mV, 5);
  payload += ",PEMshunt_mV=" + String(PEMshuntVoltage_mV, 5);
  payload += ",Loadshunt_mV=" + String(LoadshuntVoltage_mV, 5);

  payload += ",PVpower=" + String(PVpower, 5);
  payload += ",Batterypower=" + String(Batterypower, 5);
  payload += ",PEMpower=" + String(PEMpower, 5);
  payload += ",Loadpower=" + String(Loadpower, 5);

  payload += ",K1=" + String(digitalRead(K1));
  payload += ",K2=" + String(digitalRead(K2));
  payload += ",K3=" + String(digitalRead(K3));
  payload += ",K4=" + String(digitalRead(K4));
  payload += ",K5=" + String(digitalRead(K5));
  payload += ",K6=" + String(digitalRead(K6));
  payload += ",K7=" + String(digitalRead(K7));

  payload += ",requestedScenario=" + String(requestedScenario);
  payload += ",scenarioReceived=" + String(scenarioReceived ? 1 : 0);
  payload += ",loadTrigger=" + String(digitalRead(LOAD_SEQUENCE_TRIGGER_PIN));
  payload += ",mode=" + mode;
  payload += ",lastError=" + lastError;

  return payload;
}

void readMeasurements() {
  if (inaBatOk) {
    inaBat.readAndClearFlags();
    batteryVoltage = correctVoltage_V(ADDR_BAT, inaBat.getBusVoltage_V());
    BatshuntVoltage_mV = inaBat.getShuntVoltage_mV();
    Batcurrent = correctCurrent_A(ADDR_BAT, inaBat.getCurrent_mA() / 1000.0);
    Batterypower = batteryVoltage * Batcurrent;
  }

  if (inaLoadOk) {
    inaLoad.readAndClearFlags();
    loadVoltage = correctVoltage_V(ADDR_LOAD, inaLoad.getBusVoltage_V());
    LoadshuntVoltage_mV = inaLoad.getShuntVoltage_mV();
    Loadcurrent = correctCurrent_A(ADDR_LOAD, inaLoad.getCurrent_mA() / 1000.0);
    Loadpower = loadVoltage * Loadcurrent;
  }

  if (inaPVOk) {
    inaPV.readAndClearFlags();
    panelVoltage = correctVoltage_V(ADDR_PV, inaPV.getBusVoltage_V());
    PVshuntVoltage_mV = inaPV.getShuntVoltage_mV();
    PVcurrent = correctCurrent_A(ADDR_PV, inaPV.getCurrent_mA() / 1000.0);
    PVpower = panelVoltage * PVcurrent;
  }

  if (inaPEMOk) {
    inaPEM.readAndClearFlags();
    pemrfcVoltage = correctVoltage_V(ADDR_PEM, inaPEM.getBusVoltage_V());
    PEMshuntVoltage_mV = inaPEM.getShuntVoltage_mV();
    PEMcurrent = correctCurrent_A(ADDR_PEM, inaPEM.getCurrent_mA() / 1000.0);
    PEMpower = pemrfcVoltage * PEMcurrent;
  }
}

void printValues() {
  Monitor.print("Mode: ");
  Monitor.print(mode);
  Monitor.print(" PV V: ");
  Monitor.print(panelVoltage, 3);
  Monitor.print(" Bat V: ");
  Monitor.print(batteryVoltage, 3);
  Monitor.print(" PEM V: ");
  Monitor.print(pemrfcVoltage, 3);
  Monitor.print(" Load W: ");
  Monitor.println(Loadpower, 3);
}

void applyScenario(int scenario) {
  if (scenario == 1) {
    // S1: Grid -> Load
    digitalWrite(K1, HIGH);
    digitalWrite(K2, LOW);
    digitalWrite(K3, HIGH);
    digitalWrite(K4, HIGH);
    digitalWrite(K5, HIGH);
    digitalWrite(K6, HIGH);
    digitalWrite(K7, HIGH);
    mode = "S1 Grid -> Load";
  } else if (scenario == 2) {
    // S2: Grid -> Load, PV -> Battery
    digitalWrite(K1, HIGH);
    digitalWrite(K2, LOW);
    digitalWrite(K3, LOW);
    digitalWrite(K4, HIGH);
    digitalWrite(K5, HIGH);
    digitalWrite(K6, HIGH);
    digitalWrite(K7, LOW);
    mode = "S2 Grid -> Load, PV -> Battery";
  } else if (scenario == 3) {
    // S3: Grid -> Load, PV -> PEMRFC
    digitalWrite(K1, HIGH);
    digitalWrite(K2, LOW);
    digitalWrite(K3, HIGH);
    digitalWrite(K4, LOW);
    digitalWrite(K5, HIGH);
    digitalWrite(K6, HIGH);
    digitalWrite(K7, LOW);
    mode = "S3 Grid -> Load, PV -> PEMRFC";
  } else if (scenario == 4) {
    // S4: PV -> Load
    digitalWrite(K1, LOW);
    digitalWrite(K2, HIGH);
    digitalWrite(K3, HIGH);
    digitalWrite(K4, HIGH);
    digitalWrite(K5, HIGH);
    digitalWrite(K6, HIGH);
    digitalWrite(K7, LOW);
    mode = "S4 PV -> Load";
  } else if (scenario == 5) {
    // S5: Battery -> Load
    digitalWrite(K1, LOW);
    digitalWrite(K2, LOW);
    digitalWrite(K3, HIGH);
    digitalWrite(K4, HIGH);
    digitalWrite(K5, LOW);
    digitalWrite(K6, HIGH);
    digitalWrite(K7, HIGH);
    mode = "S5 Battery -> Load";
  } else if (scenario == 6) {
    // S6: PEM -> Load
    digitalWrite(K1, LOW);
    digitalWrite(K2, LOW);
    digitalWrite(K3, HIGH);
    digitalWrite(K4, HIGH);
    digitalWrite(K5, HIGH);
    digitalWrite(K6, LOW);
    digitalWrite(K7, HIGH);
    mode = "S6 PEM -> Load";
  } else {
    applyScenario(1);
    return;
  }

  setScenarioLeds(scenario);
}

void setScenarioLeds(int scenario) {
  digitalWrite(LEDS1, scenario == 1 ? HIGH : LOW);
  digitalWrite(LEDS2, scenario == 2 ? HIGH : LOW);
  digitalWrite(LEDS3, scenario == 3 ? HIGH : LOW);
  digitalWrite(LEDS4, scenario == 4 ? HIGH : LOW);
  digitalWrite(LEDS5, scenario == 5 ? HIGH : LOW);
  digitalWrite(LEDS6, scenario == 6 ? HIGH : LOW);
}

void allScenarioLedsOff() {
  digitalWrite(LEDS1, LOW);
  digitalWrite(LEDS2, LOW);
  digitalWrite(LEDS3, LOW);
  digitalWrite(LEDS4, LOW);
  digitalWrite(LEDS5, LOW);
  digitalWrite(LEDS6, LOW);
}

int relayPinFromName(String relayName) {
  if (relayName == "K1") return K1;
  if (relayName == "K2") return K2;
  if (relayName == "K3") return K3;
  if (relayName == "K4") return K4;
  if (relayName == "K5") return K5;
  if (relayName == "K6") return K6;
  if (relayName == "K7") return K7;
  return -1;
}
