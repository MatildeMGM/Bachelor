let socket = null;
let latest = null;
let userIsEditingInputs = false;

const scenarioColors = {
  1: "rgba(148, 163, 184, 0.14)",
  2: "rgba(34, 197, 94, 0.14)",
  3: "rgba(14, 165, 233, 0.14)",
  4: "rgba(250, 204, 21, 0.15)",
  5: "rgba(99, 102, 241, 0.15)",
  6: "rgba(244, 63, 94, 0.15)"
};

const lineColors = {
  demand: "rgba(255,255,255,0.48)",
  load: "#ffffff",
  pv: "#22c55e",
  battery: "#60a5fa",
  pem: "#f43f5e",
  price: "#facc15",
  threshold: "rgba(250,204,21,0.48)"
};

function $(id) {
  return document.getElementById(id);
}

function fmt(value, digits = 3) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toFixed(digits) : "-";
}

function setText(id, text) {
  const el = $(id);
  if (el) el.textContent = text;
}

function scenarioLabel(n, scenarios) {
  return scenarios?.[n] || scenarios?.[String(n)] || `S${n}`;
}

function send(action, extra = {}) {
  if (!socket) return;
  socket.emit("control", { action, ...extra });
}

function applyInputs() {
  send("set_price_mode", { price_mode: $("priceMode").value });
  send("set_price_state", { price_state: $("priceState").value });
  send("set_price_zone", { price_zone: $("priceZone").value });
  send("set_price_date", { price_date: $("priceDate").value });
  send("set_pv_mode", { pv_mode: $("pvMode").value });
  send("set_soc", {
    battery_soc: Number($("batterySoc").value),
    pem_soc: Number($("pemSoc").value)
  });

  userIsEditingInputs = false;
}

function updateSchedulingInputs(data) {
  if (userIsEditingInputs) return;

  $("priceMode").value = data.price_mode || "api";
  $("priceState").value = data.price_state || "LOW";
  $("priceZone").value = data.price_zone || "DK2";
  if ($("priceDate")) $("priceDate").value = data.price_date || "";
  $("pvMode").value = data.pv_mode || "auto";
  $("batterySoc").value = Number(data.battery_soc ?? 50).toFixed(1);
  $("pemSoc").value = Number(data.pem_soc ?? 50).toFixed(1);
}

function markInputsAsEditing() {
  userIsEditingInputs = true;
}

function renderMeasurements(status) {
  const rows = [
    ["PV voltage", `${fmt(status.panelVoltage)} V`],
    ["Battery voltage", `${fmt(status.batteryVoltage)} V`],
    ["PEM voltage", `${fmt(status.pemrfcVoltage)} V`],
    ["Load voltage", `${fmt(status.loadVoltage)} V`],
    ["PV current", `${fmt(status.PVcurrent)} A`],
    ["Battery current", `${fmt(status.Batcurrent)} A`],
    ["PEM current", `${fmt(status.PEMcurrent)} A`],
    ["Load current", `${fmt(status.Loadcurrent)} A`],
    ["PV power", `${fmt(status.PVpower)} W`],
    ["Battery power", `${fmt(status.Batterypower)} W`],
    ["PEM power", `${fmt(status.PEMpower)} W`],
    ["Load power", `${fmt(status.Loadpower)} W`],
    ["Sketch mode", status.mode || "-"]
  ];

  const tbody = $("measurementTable");
  if (!tbody) return;
  tbody.innerHTML = rows.map(([k, v]) => `<tr><th>${k}</th><td>${v}</td></tr>`).join("");
}

function renderRelays(status) {
  document.querySelectorAll(".relay-btn").forEach((btn) => {
    const relay = btn.dataset.relay;
    const value = Number(status[relay]);
    const label = Number.isFinite(value) ? (value ? "HIGH" : "LOW") : "-";
    btn.textContent = `${relay} ${label}`;
    btn.classList.toggle("active", value === 1);
  });
}

function renderScenarioButtons(actualScenario) {
  document.querySelectorAll(".scenario-btn").forEach((btn) => {
    btn.classList.toggle("active", Number(btn.dataset.scenario) === Number(actualScenario));
  });
}

function mapArray(values, fn) {
  return (values || []).map((value, index) => {
    if (value === null || value === undefined || value === "") return NaN;
    return fn(Number(value), index);
  });
}

function drawLine(ctx, values, mapX, mapY, color, width, dashed = false) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.setLineDash(dashed ? [6, 5] : []);
  ctx.beginPath();

  let started = false;

  values.forEach((value, slot) => {
    if (!Number.isFinite(value)) return;

    const x = mapX(slot);
    const y = mapY(value);

    if (!started) {
      ctx.moveTo(x, y);
      started = true;
    } else {
      ctx.lineTo(x, y);
    }
  });

  ctx.stroke();
  ctx.restore();
}

function drawHorizontalLine(ctx, value, mapY, x0, x1, color, label) {
  if (!Number.isFinite(value)) return;

  const y = mapY(value);

  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.3;
  ctx.setLineDash([5, 5]);
  ctx.beginPath();
  ctx.moveTo(x0, y);
  ctx.lineTo(x1, y);
  ctx.stroke();

  if (label) {
    ctx.fillStyle = color;
    ctx.font = "12px system-ui, sans-serif";
    ctx.fillText(label, x1 - 150, y - 6);
  }

  ctx.restore();
}

function drawTimeline(data) {
  const canvas = $("emsTimeline");
  if (!canvas) return;

  const timeline = data.timeline || {};
  const live = data.live_history || {};
  const currentSlot = Number(data.current_slot || timeline.current_slot || 0);

  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  const width = Math.max(720, Math.floor(rect.width));
  const height = 390;

  canvas.width = Math.floor(width * dpr);
  canvas.height = Math.floor(height * dpr);
  canvas.style.height = `${height}px`;

  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, height);

  const pad = { left: 62, right: 72, top: 24, bottom: 44 };
  const plotW = width - pad.left - pad.right;
  const plotH = height - pad.top - pad.bottom;

  const demandMw = mapArray(timeline.demand_w, (v) => v * 1000);
  const prices = mapArray(timeline.prices, (v) => v);

  function liveMw(name) {
    const source = live[name] || [];
    const result = [];

    for (let i = 0; i < 96; i += 1) {
      const value = source[i];
      result.push(value === null || value === undefined ? NaN : Number(value) * 1000);
    }

    return result;
  }

  // Plot objects are intentionally limited to:
  // Price, Demand, PV power, Load power, Battery power and PEM power.
  const loadMw = liveMw("load_w");
  const pvMw = liveMw("pv_w");
  const batteryMw = liveMw("battery_w");
  const pemMw = liveMw("pem_w");

  const allPowerAbs = [
    ...demandMw,
    ...loadMw,
    ...pvMw,
    ...batteryMw.map(Math.abs),
    ...pemMw.map(Math.abs)
  ].filter(Number.isFinite);

  const maxMw = Math.max(50, ...allPowerAbs);
  const minMw = -Math.max(
    10,
    ...batteryMw.filter(Number.isFinite).map((v) => Math.max(0, -v)),
    ...pemMw.filter(Number.isFinite).map((v) => Math.max(0, -v))
  );
  const powerSpan = Math.max(1, maxMw - minMw);

  const validPrices = prices.filter(Number.isFinite);
  const hasPrices = validPrices.length > 1;
  const threshold = Number(data.price_threshold);
  const priceValuesForScale = hasPrices && Number.isFinite(threshold)
    ? [...validPrices, threshold]
    : validPrices;
  const minPrice = priceValuesForScale.length ? Math.min(...priceValuesForScale) : 0;
  const maxPrice = priceValuesForScale.length ? Math.max(...priceValuesForScale) : 1;
  const priceSpan = Math.max(0.001, maxPrice - minPrice);

  const mapX = (slot) => pad.left + (slot / 95) * plotW;
  const mapPowerY = (mw) => pad.top + plotH - ((mw - minMw) / powerSpan) * plotH;
  const mapPriceY = (price) => pad.top + plotH - ((price - minPrice) / priceSpan) * plotH;

  ctx.fillStyle = "rgba(255,255,255,0.03)";
  ctx.fillRect(pad.left, pad.top, plotW, plotH);

  // Scenario background only where the moving INA log has actually recorded a slot.
  (live.scenario || []).forEach((scenario, slot) => {
    if (scenario === null || scenario === undefined) return;
    const x0 = mapX(slot);
    const x1 = mapX(Math.min(95, slot + 1));
    ctx.fillStyle = scenarioColors[Number(scenario)] || "rgba(255,255,255,0.05)";
    ctx.fillRect(x0, pad.top, Math.max(2, x1 - x0), plotH);
  });

  ctx.strokeStyle = "rgba(255,255,255,0.13)";
  ctx.lineWidth = 1;
  ctx.font = "12px system-ui, sans-serif";
  ctx.fillStyle = "rgba(255,255,255,0.72)";

  for (let i = 0; i <= 4; i += 1) {
    const value = maxMw - (powerSpan / 4) * i;
    const y = mapPowerY(value);
    ctx.beginPath();
    ctx.moveTo(pad.left, y);
    ctx.lineTo(pad.left + plotW, y);
    ctx.stroke();
    ctx.fillText(`${Math.round(value)} mW`, 10, y + 4);
  }

  const zeroY = mapPowerY(0);
  ctx.strokeStyle = "rgba(255,255,255,0.35)";
  ctx.beginPath();
  ctx.moveTo(pad.left, zeroY);
  ctx.lineTo(pad.left + plotW, zeroY);
  ctx.stroke();

  [0, 24, 48, 72, 95].forEach((slot) => {
    const x = mapX(slot);
    ctx.strokeStyle = "rgba(255,255,255,0.12)";
    ctx.beginPath();
    ctx.moveTo(x, pad.top);
    ctx.lineTo(x, pad.top + plotH);
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.72)";
    const label = timeline.labels?.[slot] || `slot ${slot}`;
    ctx.fillText(label, x - 16, height - 18);
  });

  drawLine(ctx, demandMw, mapX, mapPowerY, lineColors.demand, 1.8, true);

  if (hasPrices) {
    ctx.fillStyle = "rgba(250,204,21,0.86)";
    ctx.fillText(`${fmt(maxPrice, 2)} DKK/kWh`, width - 70, pad.top + 12);
    ctx.fillText(`${fmt(minPrice, 2)}`, width - 70, pad.top + plotH);
    drawLine(ctx, prices, mapX, mapPriceY, lineColors.price, 1.7, false);

    if (Number.isFinite(threshold)) {
      drawHorizontalLine(
        ctx,
        threshold,
        mapPriceY,
        pad.left,
        pad.left + plotW,
        lineColors.threshold,
        `HIGH threshold ${fmt(threshold, 3)}`
      );
    }
  } else {
    ctx.fillStyle = "rgba(250,204,21,0.78)";
    ctx.fillText("No API price data", width - 116, pad.top + 12);
  }

  drawLine(ctx, loadMw, mapX, mapPowerY, lineColors.load, 2.4);
  drawLine(ctx, pvMw, mapX, mapPowerY, lineColors.pv, 2.0);
  drawLine(ctx, batteryMw, mapX, mapPowerY, lineColors.battery, 2.0);
  drawLine(ctx, pemMw, mapX, mapPowerY, lineColors.pem, 2.0);

  const currentX = mapX(Math.max(0, Math.min(95, currentSlot)));
  ctx.strokeStyle = "rgba(255,255,255,0.8)";
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(currentX, pad.top - 6);
  ctx.lineTo(currentX, pad.top + plotH + 6);
  ctx.stroke();

  ctx.fillStyle = "rgba(255,255,255,0.95)";
  ctx.fillText(`slot ${currentSlot}`, Math.min(currentX + 6, width - 100), pad.top + 18);
}

function renderTimelineSummary(data) {
  const timeline = data.timeline || {};
  const live = data.live_history || {};
  const slot = Number(data.current_slot || 0);
  const scenario = live.scenario?.[slot] ?? data.actual_scenario ?? data.target_scenario;

  function liveValueText(name) {
    const liveValue = live[name]?.[slot];
    if (liveValue !== null && liveValue !== undefined && Number.isFinite(Number(liveValue))) {
      return `${fmt(Number(liveValue) * 1000, 1)} mW`;
    }
    return "not logged yet";
  }

  const priceValue = timeline.prices?.[slot];
  const priceText = priceValue !== null && priceValue !== undefined && Number.isFinite(Number(priceValue))
    ? `${fmt(priceValue, 5)} DKK/kWh (${data.price_state || "-"})`
    : `No API value (${data.price_state || "-"})`;

  setText("plotSlot", `${slot} (${data.current_interval_label || "-"})`);
  setText("plotScenario", `S${scenario}`);
  setText("plotPrice", priceText);
  setText("plotDemand", `${fmt((data.current_demand_w || 0) * 1000, 1)} mW`);
  setText("plotPV", liveValueText("pv_w"));
  setText("plotBattery", liveValueText("battery_w"));
  setText("plotPEM", liveValueText("pem_w"));
}


function render(data) {
  latest = data;
  const status = data.arduino_status || {};

  setText("modeText", data.control_mode || "-");
  setText("targetScenario", scenarioLabel(data.target_scenario, data.scenarios));
  setText("actualScenario", scenarioLabel(data.actual_scenario, data.scenarios));
  setText("decisionText", data.reason || "-");
  setText(
    "pvAvailable",
    data.pv_available
      ? `YES, latched. Leaves PV mode only if PV power < ${fmt(data.pv_min_power_w * 1000, 0)} mW`
      : `NO. Initial detection requires PV voltage > ${fmt(data.pv_threshold_v, 1)} V`
  );
  setText("pvVoltage", `${fmt(status.panelVoltage)} V`);
  setText("batterySocText", `${fmt(data.battery_soc, 1)} %`);
  setText("pemSocText", `${fmt(data.pem_soc, 1)} %`);
  setText("h2VolumeText", `${fmt(data.h2_volume_mL, 3)} mL`);
  setText("h2UsableText", `${fmt(data.h2_usable_mL, 3)} mL (${fmt(data.h2_usable_soc, 1)} %)`);
  setText("h2ModeText", `${data.h2_mode || "idle"}, Δ ${fmt(data.h2_last_delta_mL, 5)} mL/update`);
  setText("bridgeText", data.bridge_ok ? "OK" : "Not connected / error");
  setText("errorText", data.last_error || "-");

  setText("timelineTime", data.current_time_label || "-");
  setText("timelineSlot", data.current_slot ?? "-");
  setText("timelineCycle", data.demo_cycle ?? "-");
  setText("priceSource", data.price_source || "-");
  setText("priceThreshold", `${fmt(data.price_threshold, 5)} DKK/kWh`);
  setText("lastPriceUpdate", data.last_price_update || "-");
  setText("priceDateText", data.price_date || "-");
  setText("selectedPriceDate", data.price_date || "-");
  setText("priceThresholdRule", data.price_threshold_rule || "-");
  setText("simulationStatus", data.simulation_running ? "Running" : "Stopped");
  setText("loggingStatus", data.logging_enabled ? "On" : "Off");
  setText("logFile", data.log_file || "-");
  setText("lastLogUpdate", data.last_log_update || "-");

  updateSchedulingInputs(data);

  const modeBtn = $("modeBtn");
  if (modeBtn) {
    const isAuto = data.control_mode === "auto";
    modeBtn.textContent = isAuto ? "Disable automatic mode" : "Enable automatic mode";
    modeBtn.classList.toggle("active", isAuto);
  }

  renderTimelineSummary(data);
  drawTimeline(data);
  renderMeasurements(status);
  renderRelays(status);
  renderScenarioButtons(data.actual_scenario);
}

document.addEventListener("DOMContentLoaded", () => {
  socket = io(`http://${window.location.host}`);

  socket.on("connect", () => {
    setText("connectionBadge", "Connected");
    $("connectionBadge").classList.remove("bad");
    $("connectionBadge").classList.add("ok");
    socket.emit("state_request", {});
  });

  socket.on("disconnect", () => {
    setText("connectionBadge", "Disconnected");
    $("connectionBadge").classList.remove("ok");
    $("connectionBadge").classList.add("bad");
  });

  socket.on("telemetry", render);

  ["priceMode", "priceState", "priceZone", "priceDate", "pvMode", "batterySoc", "pemSoc"].forEach((id) => {
    const el = $(id);
    if (!el) return;

    el.addEventListener("input", markInputsAsEditing);
    el.addEventListener("change", markInputsAsEditing);
    el.addEventListener("focus", markInputsAsEditing);
  });

  $("modeBtn").addEventListener("click", () => {
    applyInputs();
    const nextMode = latest?.control_mode === "auto" ? "manual" : "auto";
    send("set_mode", { mode: nextMode });
  });

  $("applyInputsBtn").addEventListener("click", applyInputs);
  $("refreshBtn").addEventListener("click", () => send("refresh"));
  $("restartTimelineBtn").addEventListener("click", () => send("restart_demo"));
  $("startSimulationBtn").addEventListener("click", () => send("start_simulation"));
  $("stopSimulationBtn").addEventListener("click", () => send("stop_simulation"));
  $("resetSimulationBtn").addEventListener("click", () => send("reset_simulation"));

  document.querySelectorAll(".scenario-btn").forEach((btn) => {
    btn.addEventListener("click", () => send("manual_scenario", { scenario: Number(btn.dataset.scenario) }));
  });

  document.querySelectorAll(".relay-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const relay = btn.dataset.relay;
      const current = Number(latest?.arduino_status?.[relay]);
      send("set_relay", { relay, state: current === 1 ? 0 : 1 });
    });
  });

  window.addEventListener("resize", () => {
    if (latest) drawTimeline(latest);
  });
});
