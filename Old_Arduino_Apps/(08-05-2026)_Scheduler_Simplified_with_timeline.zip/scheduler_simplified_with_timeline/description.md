# Simplified Arduino EMS Scheduler

This version removes the old forecast/data-file based scheduler, Scenario 7, Scenario 8, and the old automatic safety/threshold logic.

The system is intentionally split into two simple parts:

- `python/main.py`: the only Python script. It owns the WebUI state, reads basic Arduino telemetry, decides the scenario, and sends scenario commands to the sketch.
- `sketch/sketch.ino`: bare Arduino functionality. It reads INA226 values, switches relays for Scenario 1-6, reports status, and accepts manual relay/scenario commands from Python.

## Automatic scenario logic

The automatic mode follows the attached flowchart:

```text
LOW price:
  PV unavailable           -> S1: Grid -> Load
  PV available, Bat <= 90% -> S2: Grid -> Load, PV -> Battery
  PV available, Bat > 90%  -> S3: Grid -> Load, PV -> PEMRFC

HIGH price:
  PV available             -> S4: PV -> Load
  PV unavailable, Bat >10% -> S5: Battery -> Load
  PV unavailable, PEM >10% -> S6: PEM -> Load
  otherwise                -> S1: Grid -> Load
```

## Notes

- The WebUI is still included.
- Scenario 7 and Scenario 8 are removed everywhere.
- No CSV logs, price files, demand files, or forecast files are used.
- Battery SoC and PEM SoC are simple WebUI inputs because the simplified Arduino sketch does not estimate SoC.
- PV availability can be automatic from measured PV voltage or manually overridden from the WebUI.
