"""
Simplified EMS controller with WebUI timeline.

One Python file only:
- Hosts the WebUI.
- Reads status from sketch.ino through Arduino_RouterBridge.
- Applies the simplified 6-scenario automatic logic.
- Sends Scenario 1-6 commands to the Arduino sketch.
- Updates virtual Battery SoC and PEM SoC by integrating measured current.
- Uses latched PV availability:
    * PV voltage > 3 V is used only to initially detect PV.
    * Once PV is latched as available, it only becomes unavailable if PV power < 10 mW.
- Fetches day-ahead electricity prices and builds a 96-step timeline.
- Generates a built-in 96-step demand curve.
- Calculates planned power flows for grid, PV, battery, PEM and load for all 96 steps.

Scenario 7 and 8 are intentionally removed.
"""

from __future__ import annotations

import json
import math
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from urllib.parse import urlencode
from urllib.request import urlopen
from zoneinfo import ZoneInfo

from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge


# ---------------------------------------------------------------------------
# General settings
# ---------------------------------------------------------------------------

BRIDGE_TIMEOUT = 1.0
LOOP_SECONDS = 1.0

DK_TZ = ZoneInfo("Europe/Copenhagen")
PRICE_API_URL = "https://api.energidataservice.dk/dataset/DayAheadPrices"
PRICE_SOURCE = "api.energidataservice.dk"
VALID_PRICE_ZONES = ("DK1", "DK2")
PRICE_REQUEST_TIMEOUT = 8

# Demonstration timeline: one 24-hour day is replayed in 12 real minutes.
# This is only used for the 96-step plot index and API price lookup.
DEMO_DAY_SECONDS = 12 * 60
DEMO_SLOT_COUNT = 96
DEMO_SLOT_SECONDS = DEMO_DAY_SECONDS / DEMO_SLOT_COUNT

PV_AVAILABLE_VOLTAGE = 3.0
PV_MIN_POWER_W = 0.010  # 10 mW

SCENARIOS = {
    1: "S1: Grid -> Load",
    2: "S2: Grid -> Load, PV -> Battery",
    3: "S3: Grid -> Load, PV -> PEMRFC",
    4: "S4: PV -> Load",
    5: "S5: Battery -> Load",
    6: "S6: PEM -> Load",
}


# ---------------------------------------------------------------------------
# Virtual SoC settings
# ---------------------------------------------------------------------------

BATTERY_CAPACITY_MAH = 10.0

PEM_DISCHARGE_CAPACITY_MAH = 10.0
PEM_CHARGE_CAPACITY_MAH = 20.0
# PEM charging capacity is 20 mAh because efficiency is approximately 50%.
# This means it needs about 20 mAh of charging current-time to reach 100%,
# but only contains about 10 mAh of usable discharge capacity.

MIN_SOC = 0.0
MAX_SOC = 100.0

MAX_SOC_INTEGRATION_DT_SECONDS = 10.0
last_soc_update_time = time.time()


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

@dataclass
class ControllerState:
    control_mode: str = "manual"  # "manual" or "auto"

    # Price can be controlled manually or from the 96-step API timeline.
    price_mode: str = "api"       # "api" or "manual"
    price_state: str = "LOW"      # "LOW" or "HIGH"
    price_zone: str = "DK2"
    current_price: float = 0.0
    price_threshold: float = 0.0
    prices: list[float] | None = None
    last_price_update: str = ""
    price_source: str = PRICE_SOURCE

    # Built-in 96-step demand profile.
    demand_profile: list[float] | None = None
    current_demand_w: float = 0.0
    last_demand_update: str = ""

    # Demo timeline index.
    demo_start_time: float = time.time()
    demo_cycle: int = 0
    current_slot: int = 0
    current_time_label: str = "00:00"
    current_interval_label: str = "00:00-00:15"

    pv_mode: str = "auto"         # "auto", "force_available", "force_unavailable"
    pv_latched_available: bool = False

    battery_soc: float = 50.0
    pem_soc: float = 50.0

    target_scenario: int = 1
    actual_scenario: int = 1

    reason: str = "Manual mode: waiting for command."
    bridge_ok: bool = False
    last_error: str = ""

    arduino_status: dict | None = None

    # 96-step planned timeline calculated from prices, demand, current SoC and PV state.
    timeline: dict | None = None


ui = WebUI()
state = ControllerState()
state_lock = threading.Lock()
known_clients = set()


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------

def get_now() -> datetime:
    return datetime.now(DK_TZ)


def clamp(value: float, minimum: float = MIN_SOC, maximum: float = MAX_SOC) -> float:
    return max(minimum, min(maximum, value))


def safe_float(value, default: float = 0.0) -> float:
    try:
        number = float(value)
        if math.isfinite(number):
            return number
        return default
    except (TypeError, ValueError):
        return default


def pad2(value: int) -> str:
    return str(value).zfill(2)


def slot_time_label(slot: int) -> str:
    slot = int(slot) % DEMO_SLOT_COUNT
    hour = slot // 4
    minute = (slot % 4) * 15
    return f"{pad2(hour)}:{pad2(minute)}"


def slot_interval_label(slot: int) -> str:
    start = slot_time_label(slot)
    end = slot_time_label((int(slot) + 1) % DEMO_SLOT_COUNT)
    return f"{start}-{end}"


def parse_status(raw: str) -> dict:
    """
    Parse key=value,key=value status string from the Arduino sketch.

    Example:
    panelVoltage=4.2,Batcurrent=0.013,PEMcurrent=-0.008,mode=S2
    """
    result = {}

    if not raw:
        return result

    for part in str(raw).split(","):
        if "=" not in part:
            continue

        key, value = part.split("=", 1)
        key = key.strip()
        value = value.strip()

        if key == "mode":
            result[key] = value
            continue

        try:
            if "." in value or "e" in value.lower():
                result[key] = float(value)
            else:
                result[key] = int(value)
        except ValueError:
            result[key] = value

    return result


def scenario_from_mode(mode: str) -> int:
    if not mode:
        return 0

    for n in SCENARIOS:
        if f"S{n}" in mode:
            return n

    return 0


# ---------------------------------------------------------------------------
# 96-step price and demand inputs
# ---------------------------------------------------------------------------

def make_default_demand_profile() -> list[float]:
    """
    Built-in 96-step demand profile in W.

    The shape has a low night load, a morning rise and an evening peak.
    This replaces the old CSV demand file while keeping the same 96 timestep idea.
    """
    values = []

    for slot in range(DEMO_SLOT_COUNT):
        hour = slot / 4.0

        base = 0.025
        morning_peak = 0.055 * math.exp(-0.5 * ((hour - 7.5) / 1.6) ** 2)
        daytime = 0.025 * math.exp(-0.5 * ((hour - 13.0) / 4.0) ** 2)
        evening_peak = 0.090 * math.exp(-0.5 * ((hour - 19.0) / 2.1) ** 2)
        night_dip = -0.010 * math.exp(-0.5 * ((hour - 3.0) / 1.7) ** 2)

        demand_w = max(0.020, base + morning_peak + daytime + evening_peak + night_dip)
        values.append(round(demand_w, 5))

    return values


def fallback_price_profile() -> list[float]:
    """
    Fallback 96-step price profile in DKK/kWh.

    Used when the external API is unavailable so the plot still works.
    """
    values = []

    for slot in range(DEMO_SLOT_COUNT):
        hour = slot / 4.0
        morning = 0.35 * math.exp(-0.5 * ((hour - 8.0) / 2.0) ** 2)
        evening = 0.55 * math.exp(-0.5 * ((hour - 18.5) / 2.6) ** 2)
        night_low = -0.18 * math.exp(-0.5 * ((hour - 3.0) / 2.2) ** 2)
        price = 0.75 + morning + evening + night_low
        values.append(round(max(0.05, price), 5))

    return values


def fetch_day_ahead_prices(zone: str = "DK2") -> list[float]:
    """
    Fetch day-ahead prices and return 96 values in DKK/kWh.

    The Energi Data Service DayAheadPrices dataset is hourly. Each hourly value
    is repeated four times to match the 15-minute / 96-step EMS timeline.
    """
    zone = zone if zone in VALID_PRICE_ZONES else "DK2"
    now = get_now()
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=1)

    params = {
        "start": start.isoformat(),
        "end": end.isoformat(),
        "filter": json.dumps({"PriceArea": [zone]}),
        "sort": "HourDK",
        "timezone": "dk",
        "limit": "100",
    }

    url = PRICE_API_URL + "?" + urlencode(params)

    with urlopen(url, timeout=PRICE_REQUEST_TIMEOUT) as response:
        payload = json.loads(response.read().decode("utf-8"))

    records = payload.get("records", [])
    hourly_prices = []

    for record in records:
        if str(record.get("PriceArea", "")).upper() != zone:
            continue

        raw_price = record.get("SpotPriceDKK", record.get("PriceDKK"))
        price_dkk_per_mwh = safe_float(raw_price, None)

        if price_dkk_per_mwh is None:
            continue

        hourly_prices.append(price_dkk_per_mwh / 1000.0)  # DKK/MWh -> DKK/kWh

    if not hourly_prices:
        raise ValueError("No prices returned from API")

    hourly_prices = hourly_prices[:24]

    while len(hourly_prices) < 24:
        hourly_prices.append(hourly_prices[-1])

    prices_96 = []
    for price in hourly_prices:
        prices_96.extend([round(float(price), 5)] * 4)

    return prices_96[:DEMO_SLOT_COUNT]


def refresh_prices() -> None:
    try:
        prices = fetch_day_ahead_prices(state.price_zone)
        state.prices = prices
        state.last_price_update = get_now().isoformat(timespec="seconds")
        state.price_source = PRICE_SOURCE
        state.last_error = ""
    except Exception as exc:
        state.prices = fallback_price_profile()
        state.last_price_update = get_now().isoformat(timespec="seconds")
        state.price_source = "fallback profile"
        state.last_error = f"Price API failed, using fallback profile: {exc}"

    update_price_threshold()


def refresh_demand_profile() -> None:
    state.demand_profile = make_default_demand_profile()
    state.last_demand_update = get_now().isoformat(timespec="seconds")


def update_price_threshold() -> None:
    prices = state.prices or []
    valid = sorted(p for p in prices if isinstance(p, (int, float)) and math.isfinite(float(p)))

    if not valid:
        state.price_threshold = 0.0
        return

    # Median threshold: upper half of the day is HIGH, lower half is LOW.
    state.price_threshold = float(valid[len(valid) // 2])


def price_state_for_slot(slot: int) -> str:
    prices = state.prices or []
    if slot < 0 or slot >= len(prices):
        return state.price_state

    price = safe_float(prices[slot], 0.0)
    threshold = safe_float(state.price_threshold, 0.0)
    return "HIGH" if price >= threshold else "LOW"


def update_demo_slot() -> None:
    elapsed = max(0.0, time.time() - state.demo_start_time)
    absolute_slot = int(elapsed / DEMO_SLOT_SECONDS)

    state.demo_cycle = absolute_slot // DEMO_SLOT_COUNT
    state.current_slot = absolute_slot % DEMO_SLOT_COUNT
    state.current_time_label = slot_time_label(state.current_slot)
    state.current_interval_label = slot_interval_label(state.current_slot)


def update_current_timeline_inputs() -> None:
    slot = state.current_slot

    if state.prices and slot < len(state.prices):
        state.current_price = safe_float(state.prices[slot], 0.0)
    else:
        state.current_price = 0.0

    if state.demand_profile and slot < len(state.demand_profile):
        state.current_demand_w = safe_float(state.demand_profile[slot], 0.0)
    else:
        state.current_demand_w = 0.0

    if state.price_mode == "api":
        state.price_state = price_state_for_slot(slot)


# ---------------------------------------------------------------------------
# Arduino bridge communication
# ---------------------------------------------------------------------------

def fetch_arduino_status() -> dict:
    raw = Bridge.call("get_status", timeout=BRIDGE_TIMEOUT)
    return parse_status(raw)


def send_scenario_to_arduino(scenario: int) -> None:
    scenario = int(scenario)

    if scenario not in SCENARIOS:
        scenario = 1

    Bridge.call(
        "apply_scenario_frame",
        f"SCENARIO,{scenario}",
        timeout=BRIDGE_TIMEOUT,
    )


def send_relay_to_arduino(relay: str, output_state: int) -> None:
    relay = str(relay).upper()
    value = 1 if int(output_state) else 0

    Bridge.call(
        "apply_relay_frame",
        f"RELAY,{relay},{value}",
        timeout=BRIDGE_TIMEOUT,
    )


# ---------------------------------------------------------------------------
# SoC integration
# ---------------------------------------------------------------------------

def integrate_soc(
    current_a: float,
    dt_seconds: float,
    current_soc: float,
    charge_capacity_mah: float,
    discharge_capacity_mah: float,
) -> float:
    """
    Integrate current into SoC.

    Sign convention:
    positive current = charging
    negative current = discharging
    """
    if dt_seconds <= 0:
        return current_soc

    current_ma = current_a * 1000.0
    dt_hours = dt_seconds / 3600.0
    delta_mah = current_ma * dt_hours

    if delta_mah >= 0:
        delta_soc = (delta_mah / charge_capacity_mah) * 100.0
    else:
        delta_soc = (delta_mah / discharge_capacity_mah) * 100.0

    return clamp(current_soc + delta_soc)


def update_virtual_socs_from_current(arduino_status: dict | None) -> None:
    global last_soc_update_time

    now = time.time()
    dt_seconds = now - last_soc_update_time
    last_soc_update_time = now

    if not arduino_status:
        return

    if dt_seconds <= 0 or dt_seconds > MAX_SOC_INTEGRATION_DT_SECONDS:
        return

    battery_current = safe_float(arduino_status.get("Batcurrent", 0.0), 0.0)
    pem_current = safe_float(arduino_status.get("PEMcurrent", 0.0), 0.0)

    state.battery_soc = integrate_soc(
        current_a=battery_current,
        dt_seconds=dt_seconds,
        current_soc=state.battery_soc,
        charge_capacity_mah=BATTERY_CAPACITY_MAH,
        discharge_capacity_mah=BATTERY_CAPACITY_MAH,
    )

    state.pem_soc = integrate_soc(
        current_a=pem_current,
        dt_seconds=dt_seconds,
        current_soc=state.pem_soc,
        charge_capacity_mah=PEM_CHARGE_CAPACITY_MAH,
        discharge_capacity_mah=PEM_DISCHARGE_CAPACITY_MAH,
    )


def reset_soc_initial_condition(battery_soc: float, pem_soc: float) -> None:
    global last_soc_update_time

    state.battery_soc = clamp(float(battery_soc))
    state.pem_soc = clamp(float(pem_soc))
    last_soc_update_time = time.time()


# ---------------------------------------------------------------------------
# PV availability latch
# ---------------------------------------------------------------------------

def measured_pv_initially_available(status: dict | None) -> bool:
    if not status:
        return False

    panel_voltage = safe_float(status.get("panelVoltage", 0.0), 0.0)
    return panel_voltage > PV_AVAILABLE_VOLTAGE


def measured_pv_power_too_low(status: dict | None) -> bool:
    if not status:
        return True

    pv_power = safe_float(status.get("PVpower", 0.0), 0.0)
    return pv_power < PV_MIN_POWER_W


def update_pv_latch() -> None:
    if state.pv_mode == "force_available":
        state.pv_latched_available = True
        return

    if state.pv_mode == "force_unavailable":
        state.pv_latched_available = False
        return

    if not state.pv_latched_available:
        state.pv_latched_available = measured_pv_initially_available(state.arduino_status)
        return

    if measured_pv_power_too_low(state.arduino_status):
        state.pv_latched_available = False


def pv_available_from_state() -> bool:
    return state.pv_latched_available


# ---------------------------------------------------------------------------
# Scenario decision and timeline power-flow model
# ---------------------------------------------------------------------------

def decide_scenario_for_inputs(price_state: str, pv_available: bool, battery_soc: float, pem_soc: float) -> tuple[int, str]:
    price_high = str(price_state).upper() == "HIGH"

    if not price_high:
        if not pv_available:
            return 1, "LOW price and PV unavailable -> S1."

        if battery_soc > 90.0:
            return 3, "LOW price, PV available, battery SoC > 90% -> S3."

        return 2, "LOW price, PV available, battery SoC <= 90% -> S2."

    if pv_available:
        return 4, "HIGH price and PV available -> S4."

    if battery_soc > 10.0:
        return 5, "HIGH price, PV unavailable, battery SoC > 10% -> S5."

    if pem_soc > 10.0:
        return 6, "HIGH price, PV unavailable, battery SoC <= 10%, PEM SoC > 10% -> S6."

    return 1, "HIGH price, PV unavailable, battery SoC <= 10%, PEM SoC <= 10% -> S1."


def decide_scenario() -> tuple[int, str]:
    return decide_scenario_for_inputs(
        price_state=state.price_state,
        pv_available=pv_available_from_state(),
        battery_soc=state.battery_soc,
        pem_soc=state.pem_soc,
    )


def current_pv_power_estimate_w() -> float:
    status = state.arduino_status or {}
    measured = safe_float(status.get("PVpower", 0.0), 0.0)

    if measured >= PV_MIN_POWER_W:
        return measured

    if pv_available_from_state():
        # Use a small but visible charging value for the future plot if PV is
        # latched available but the current measured PV power is momentarily low.
        return max(PV_MIN_POWER_W, 0.030)

    return 0.0


def flow_for_scenario(scenario: int, demand_w: float, pv_charge_power_w: float) -> dict:
    """
    Return component power flows for one slot.

    Sign convention for storage components in the plot:
    - positive battery/pem = discharging to load
    - negative battery/pem = charging
    """
    demand_w = max(0.0, safe_float(demand_w, 0.0))
    pv_charge_power_w = max(0.0, safe_float(pv_charge_power_w, 0.0))

    flow = {
        "grid_w": 0.0,
        "pv_w": 0.0,
        "battery_w": 0.0,
        "pem_w": 0.0,
        "load_w": demand_w,
    }

    if scenario == 1:
        flow["grid_w"] = demand_w
    elif scenario == 2:
        flow["grid_w"] = demand_w
        flow["pv_w"] = pv_charge_power_w
        flow["battery_w"] = -pv_charge_power_w
    elif scenario == 3:
        flow["grid_w"] = demand_w
        flow["pv_w"] = pv_charge_power_w
        flow["pem_w"] = -pv_charge_power_w
    elif scenario == 4:
        flow["pv_w"] = demand_w
    elif scenario == 5:
        flow["battery_w"] = demand_w
    elif scenario == 6:
        flow["pem_w"] = demand_w
    else:
        flow["grid_w"] = demand_w

    return flow


def build_timeline() -> dict:
    prices = list(state.prices or fallback_price_profile())[:DEMO_SLOT_COUNT]
    demand = list(state.demand_profile or make_default_demand_profile())[:DEMO_SLOT_COUNT]

    while len(prices) < DEMO_SLOT_COUNT:
        prices.append(prices[-1] if prices else 0.0)

    while len(demand) < DEMO_SLOT_COUNT:
        demand.append(demand[-1] if demand else 0.02)

    pv_available = pv_available_from_state()
    pv_charge_power_w = current_pv_power_estimate_w()

    price_states = []
    scenarios = []
    grid_w = []
    pv_w = []
    battery_w = []
    pem_w = []
    load_w = []
    labels = []

    for slot in range(DEMO_SLOT_COUNT):
        slot_price_state = price_state_for_slot(slot) if state.price_mode == "api" else state.price_state
        scenario, _reason = decide_scenario_for_inputs(
            price_state=slot_price_state,
            pv_available=pv_available,
            battery_soc=state.battery_soc,
            pem_soc=state.pem_soc,
        )
        flow = flow_for_scenario(scenario, demand[slot], pv_charge_power_w)

        price_states.append(slot_price_state)
        scenarios.append(scenario)
        grid_w.append(round(flow["grid_w"], 5))
        pv_w.append(round(flow["pv_w"], 5))
        battery_w.append(round(flow["battery_w"], 5))
        pem_w.append(round(flow["pem_w"], 5))
        load_w.append(round(flow["load_w"], 5))
        labels.append(slot_time_label(slot))

    return {
        "slot_count": DEMO_SLOT_COUNT,
        "current_slot": state.current_slot,
        "labels": labels,
        "prices": prices,
        "price_states": price_states,
        "demand_w": demand,
        "scenarios": scenarios,
        "flows": {
            "grid_w": grid_w,
            "pv_w": pv_w,
            "battery_w": battery_w,
            "pem_w": pem_w,
            "load_w": load_w,
        },
        "units": {
            "power": "W",
            "price": "DKK/kWh",
        },
    }


def update_timeline() -> None:
    state.timeline = build_timeline()


# ---------------------------------------------------------------------------
# State update and publishing
# ---------------------------------------------------------------------------

def refresh_status() -> None:
    try:
        status = fetch_arduino_status()

        state.arduino_status = status
        state.actual_scenario = scenario_from_mode(str(status.get("mode", ""))) or state.target_scenario
        state.bridge_ok = True
        state.last_error = ""

        update_virtual_socs_from_current(status)
        update_pv_latch()

    except Exception as exc:
        state.bridge_ok = False
        state.last_error = f"Bridge error: {exc}"


def apply_target_scenario(scenario: int, reason: str) -> None:
    scenario = int(scenario)

    if scenario not in SCENARIOS:
        scenario = 1

    state.target_scenario = scenario
    state.reason = reason

    try:
        send_scenario_to_arduino(scenario)
        refresh_status()

    except Exception as exc:
        state.bridge_ok = False
        state.last_error = f"Bridge error: {exc}"


def update_runtime_inputs() -> None:
    update_demo_slot()
    update_current_timeline_inputs()
    update_timeline()


def build_payload() -> dict:
    payload = asdict(state)
    payload["scenarios"] = SCENARIOS
    payload["pv_available"] = pv_available_from_state()
    payload["pv_threshold_v"] = PV_AVAILABLE_VOLTAGE
    payload["pv_min_power_w"] = PV_MIN_POWER_W

    payload["battery_capacity_mah"] = BATTERY_CAPACITY_MAH
    payload["pem_discharge_capacity_mah"] = PEM_DISCHARGE_CAPACITY_MAH
    payload["pem_charge_capacity_mah"] = PEM_CHARGE_CAPACITY_MAH

    payload["valid_price_zones"] = VALID_PRICE_ZONES
    payload["demo_slot_seconds"] = DEMO_SLOT_SECONDS

    return payload


def publish() -> None:
    with state_lock:
        payload = build_payload()

    ui.send_message("telemetry", payload)


def api_status():
    with state_lock:
        return build_payload()


# ---------------------------------------------------------------------------
# Main control loop
# ---------------------------------------------------------------------------

def control_loop() -> None:
    while True:
        with state_lock:
            update_runtime_inputs()
            refresh_status()
            update_runtime_inputs()

            if state.control_mode == "auto":
                scenario, reason = decide_scenario()

                if scenario != state.target_scenario:
                    apply_target_scenario(scenario, reason)
                else:
                    state.reason = reason

            update_timeline()

        publish()
        time.sleep(LOOP_SECONDS)


# ---------------------------------------------------------------------------
# WebUI event handlers
# ---------------------------------------------------------------------------

def on_state_request(client_id, data):
    known_clients.add(client_id)
    publish()


def on_control(client_id, data):
    known_clients.add(client_id)

    data = data or {}
    action = data.get("action", "")

    with state_lock:
        update_runtime_inputs()

        if action == "refresh":
            refresh_prices()
            refresh_demand_profile()
            refresh_status()
            update_runtime_inputs()

        elif action == "restart_demo":
            state.demo_start_time = time.time()
            state.demo_cycle = 0
            state.current_slot = 0
            update_runtime_inputs()
            state.reason = "Timeline restarted from slot 0."

        elif action == "set_mode":
            state.control_mode = "auto" if data.get("mode") == "auto" else "manual"

            if state.control_mode == "auto":
                refresh_status()
                update_runtime_inputs()
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)
            else:
                state.reason = "Manual mode enabled. Automatic scenario changes are disabled."

        elif action == "set_price_mode":
            value = data.get("price_mode", "api")
            state.price_mode = "manual" if value == "manual" else "api"
            update_runtime_inputs()

            if state.control_mode == "auto":
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "set_price_state":
            state.price_state = "HIGH" if data.get("price_state") == "HIGH" else "LOW"

            if state.price_mode == "api":
                # Manual price input is only used when price mode is manual.
                update_current_timeline_inputs()

            if state.control_mode == "auto":
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "set_price_zone":
            zone = str(data.get("price_zone", state.price_zone)).upper()
            if zone in VALID_PRICE_ZONES:
                state.price_zone = zone
                refresh_prices()
                update_runtime_inputs()
            else:
                state.last_error = "Invalid price zone. Use DK1 or DK2."

            if state.control_mode == "auto":
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "set_pv_mode":
            value = data.get("pv_mode", "auto")

            if value in {"auto", "force_available", "force_unavailable"}:
                state.pv_mode = value
            else:
                state.pv_mode = "auto"

            update_pv_latch()
            update_timeline()

            if state.control_mode == "auto":
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "set_soc":
            try:
                battery_soc = data.get("battery_soc", state.battery_soc)
                pem_soc = data.get("pem_soc", state.pem_soc)

                reset_soc_initial_condition(
                    battery_soc=safe_float(battery_soc, state.battery_soc),
                    pem_soc=safe_float(pem_soc, state.pem_soc),
                )

                state.reason = (
                    "Manual SoC input applied as new initial condition. "
                    "Current integration continues from this value."
                )

            except (TypeError, ValueError):
                state.last_error = "Invalid SoC input."

            update_timeline()

            if state.control_mode == "auto":
                scenario, reason = decide_scenario()
                apply_target_scenario(scenario, reason)

        elif action == "manual_scenario":
            try:
                scenario = int(data.get("scenario", 1))
            except (TypeError, ValueError):
                scenario = 1

            state.control_mode = "manual"
            apply_target_scenario(scenario, f"Manual scenario command -> S{scenario}.")

        elif action == "set_relay":
            relay = str(data.get("relay", "")).upper()

            try:
                output_state = 1 if int(data.get("state", 0)) else 0
            except (TypeError, ValueError):
                output_state = 0

            if relay not in {"K1", "K2", "K3", "K4", "K5", "K6", "K7"}:
                state.last_error = "Invalid relay name."

            else:
                state.control_mode = "manual"

                try:
                    send_relay_to_arduino(relay, output_state)
                    refresh_status()
                    state.reason = f"Manual relay command: {relay} = {output_state}."

                except Exception as exc:
                    state.bridge_ok = False
                    state.last_error = f"Bridge error: {exc}"

        update_runtime_inputs()

    publish()


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------

def setup_ui() -> None:
    ui.expose_api("GET", "/api/status", api_status)
    ui.on_message("state_request", on_state_request)
    ui.on_message("control", on_control)


with state_lock:
    refresh_demand_profile()
    refresh_prices()
    update_runtime_inputs()

setup_ui()

threading.Thread(target=control_loop, daemon=True).start()

print("Starting simplified EMS app with timeline, energy prices and planned power flows...")

App.run()
