# Bachelor
We aim to build a model that controls an Energy Management System (EMS) in a smart way, ensuring stable and optimal integration with the grid while operating in a cost-effective manner.


Arduino App with Python and Arduino sketch components. .vscode includes tasks to upload project the projects to the board. To make this process as fast as possible several steps are taken:

Sketch is compiled locally and flashed to the board.
A python virtual environment is created to enable linting locally.
.vscode/c_cpp_properties.json is generated to enable IntelliSense for the Arduino sketch.


Start app : adb shell "cd /home/arduino/ArduinoApps/bachelor_vs_control && arduino-app-cli app start ."

Stop app : adb shell "cd /home/arduino/ArduinoApps/bachelor_vs_control && arduino-app-cli app stop ."



i remote: 

cd /home/arduino/ArduinoApps/bachelor_vs_control
arduino-app-cli app stop .
arduino-app-cli app start .

Sketch ændringer: arduino-cli compile --upload -p COM3 -b arduino:zephyr:unoq sketch
Main andringer - save file and start app

overvåg: arduino-app-cli app logs .