Scenario 1: 
price=0.30
pv=0.00
bat=2.40
pem=0.00
load=0.00
bati=0.00
pemi=-0.20
pvi=0.00
loadi=0.00


Scenario 2:
price=0.30
pv=2.50
bat=3.20
pem=0.00
load=0.30
bati=0.00
pemi=-0.20
pvi=0.20
loadi=0.10


Scenario 3: 
price=0.30
pv=2.50
bat=3.90
pem=0.60
load=0.30
bati=0.00
pemi=0.00
pvi=0.20
loadi=0.10

Scenario 4: 
price=0.80
pv=2.50
bat=3.20
pem=0.60
load=0.30
bati=0.00
pemi=0.00
pvi=0.30
loadi=0.10


Scenario 5: 
price=0.80
pv=2.50
bat=3.20
pem=0.60
load=0.30
bati=0.00
pemi=0.00
pvi=0.30
loadi=0.10


Scenario 6: 
price=0.80
pv=0.00
bat=2.40
pem=0.90
load=0.30
bati=0.00
pemi=0.20
pvi=0.00
loadi=0.10