#include <Arduino_RouterBridge.h>

// Pin definitions
const int LEDS1 = 13;
const int LEDS2 = 8;
const int LEDS3 = 6;
const int LEDS4 = 4;
const int LEDS5 = 3;
const int LEDS6 = 2;

// Electricity price time management
unsigned long previousMillis = 0;
const long period = 20000; // Period at which energy prices should change
int hour = 0;

// App start/stop heartbeat management
unsigned long lastHeartbeat = 0;
const unsigned long heartbeatTimeout = 2000;
bool appRunning = false;

// PEMRFC time management
const long period2 = 60000; // Period at which PEMRFC gets status charged
unsigned long starttime = 0;
bool PEM_flag = false;

// Declaring global variables for simulated sensor data
float nominalVoltage = 5.0;
float panelVoltage = 0.0;
float loadVoltage = 0.0;
float pemrfcVoltage = 0.0;
float batteryVoltage = 0.0;
float batterySOC = 0.0;
float PVcurrent = 0.0;
float Loadcurrent = 0.0;
float PEMcurrent = 0.0;
float Batcurrent = 0.0;
float PVpower = 0.0;
float Loadpower = 0.0;
float PEMpower = 0.0;
float Batterypower = 0.0;
float electricityprice = 0.0;
int waterlevel = 0;
String mode = "";

// Battery and PEM gets status charged when running script
bool pemCharged = true;
bool batCharged = true;

// Electricity price status from MPU
bool priceReceived = false;

// Optional manual scenario override
int manualScenario = 0;

void Scenario1();
void Scenario2();
void Scenario3();
void Scenario4();
void Scenario5();
void Scenario6();
void HighPriceScheme();
void LowPriceScheme();
void GetVoltage();
void GetCurrent();
void GetPower();
void UpdatePrices();
void PrintValues();
void SafeState();

bool apply_price_frame(String payload);
bool apply_control_frame(String payload);
void heartbeat();

void setup() {
  Serial.begin(9600);
  Serial.println("EMS sketch started");


  // Initialize Bridge
  Bridge.begin();
  Bridge.provide("apply_price_frame", apply_price_frame);
  Bridge.provide("apply_control_frame", apply_control_frame);
  Bridge.provide("heartbeat", heartbeat);

  // Initialize the pinmodes
  pinMode(LEDS1, OUTPUT);
  pinMode(LEDS2, OUTPUT);
  pinMode(LEDS3, OUTPUT);
  pinMode(LEDS4, OUTPUT);
  pinMode(LEDS5, OUTPUT);
  pinMode(LEDS6, OUTPUT);
  
  
  digitalWrite(LEDS1, HIGH);
  digitalWrite(LEDS2, HIGH);
  delay(1000);
  digitalWrite(LEDS1, LOW);
  digitalWrite(LEDS2, LOW);



  // Begin scenario 1
  Scenario1();

  // Initialize first electricity price
  electricityprice = 0.0;
}

void loop()
{
  
  Serial.println("Loop running");

    // App stop / watchdog handling
  if (millis() - lastHeartbeat > heartbeatTimeout) {
    appRunning = false;
  }

  if (!appRunning) {
    SafeState();
    delay(100);
    return;
  }

  UpdatePrices();   // Update Electricity prices every 20 second
  GetVoltage();     // Voltage measurements
  GetCurrent();     // Current measurements
  GetPower();       // Get power calculations

  PrintValues();    // Printing values

  if (manualScenario >= 1 && manualScenario <= 6) {
    if (manualScenario == 1) Scenario1();
    else if (manualScenario == 2) Scenario2();
    else if (manualScenario == 3) Scenario3();
    else if (manualScenario == 4) Scenario4();
    else if (manualScenario == 5) Scenario5();
    else if (manualScenario == 6) Scenario6();
  } else {
    if (electricityprice >= 0.6) {
      HighPriceScheme(); // Discharge
    } else if (electricityprice < 0.6) {
      LowPriceScheme(); // Charge
    }
  }

  delay(400);

  // PEM charging time handling
  if (manualScenario != 3 && manualScenario != 6) {
    starttime = 0;
    PEM_flag = false;
  }
}

void heartbeat() {
  appRunning = true;
  lastHeartbeat = millis();
}

void SafeState() {
  digitalWrite(LEDS1, LOW);
  digitalWrite(LEDS2, LOW);
  digitalWrite(LEDS3, LOW);
  digitalWrite(LEDS4, LOW);
  digitalWrite(LEDS5, LOW);
  digitalWrite(LEDS6, LOW);
  mode = "App stopped / Safe state";
}

void HighPriceScheme() {
  if (panelVoltage > 2.0 && loadVoltage > 0.15) {
    Scenario4();
  } else if (batCharged && batteryVoltage > 2.6) {
    Scenario5();
  } else if ((pemCharged && pemrfcVoltage > 0.5) && loadVoltage > 0.2) {
    Scenario6();
    batCharged = false;
  } else {
    pemCharged = false;
    batCharged = false;
    Scenario1();
  }
}

void LowPriceScheme() {
  if (panelVoltage > 2.0 || PEM_flag == true) {
    if (((batteryVoltage < 3.805) && (Batcurrent >= -0.1) && (PEM_flag == false)) ||
        ((Batcurrent >= -0.1) && (batteryVoltage <= 3.66) && (PEM_flag == false))) {
      Scenario2();
      if (batteryVoltage > 2.75) {
        batCharged = true;
      }
    } else if (PEMcurrent >= -0.1) {
      Scenario3();
      PEM_flag = true;
      if (pemCharged == false && starttime == 0) {
        starttime = millis(); // store the current time
      }
      if (millis() - starttime >= period2) { // check if 60000ms have passed
        pemCharged = true;
      }
    } else {
      Scenario1();
    }
  } else {
    Scenario1();
  }
}

void GetVoltage() {
  // Simulated values are updated from Python through Bridge
}

void GetCurrent() {
  // Simulated values are updated from Python through Bridge
}

void GetPower() {
  // Calculating power:
  PVpower = PVcurrent * panelVoltage;
  Loadpower = Loadcurrent * loadVoltage;
  PEMpower = PEMcurrent * pemrfcVoltage;
  Batterypower = Batcurrent * batteryVoltage;
}

void UpdatePrices() {
  unsigned long currentMillis = millis(); // store the current time
  if (currentMillis - previousMillis >= period) { // check if 20000ms passed
    previousMillis = currentMillis; // save the last time the hour changed

    // Update hour
    if (hour == 23) {
      hour = 0;
    } else {
      hour = hour + 1;
    }
  }
}

bool apply_price_frame(String payload) {
  if (!payload.startsWith("PRICE,")) {
    return false;
  }

  int firstComma = payload.indexOf(',');
  int secondComma = payload.indexOf(',', firstComma + 1);

  if (firstComma < 0 || secondComma < 0) {
    return false;
  }

  electricityprice = payload.substring(firstComma + 1, secondComma).toFloat();
  hour = payload.substring(secondComma + 1).toInt();
  priceReceived = true;

  return true;
}

bool apply_control_frame(String payload) {
  if (!payload.startsWith("CTRL,")) {
    return false;
  }

  int indexes[10];
  int fromIndex = 0;

  for (int i = 0; i < 10; i++) {
    indexes[i] = payload.indexOf(',', fromIndex);
    if (indexes[i] < 0 && i < 9) {
      return false;
    }
    fromIndex = indexes[i] + 1;
  }

  electricityprice = payload.substring(indexes[0] + 1, indexes[1]).toFloat();
  hour = payload.substring(indexes[1] + 1, indexes[2]).toInt();
  panelVoltage = payload.substring(indexes[2] + 1, indexes[3]).toFloat();
  batteryVoltage = payload.substring(indexes[3] + 1, indexes[4]).toFloat();
  pemrfcVoltage = payload.substring(indexes[4] + 1, indexes[5]).toFloat();
  loadVoltage = payload.substring(indexes[5] + 1, indexes[6]).toFloat();
  Batcurrent = payload.substring(indexes[6] + 1, indexes[7]).toFloat();
  PEMcurrent = payload.substring(indexes[7] + 1, indexes[8]).toFloat();
  PVcurrent = payload.substring(indexes[8] + 1, indexes[9]).toFloat();
  Loadcurrent = payload.substring(indexes[9] + 1).toFloat();

  Serial.print("USED PRICE: ");
  Serial.println(electricityprice, 3);
  Serial.print("USED PV: ");
  Serial.println(panelVoltage, 3);
  Serial.print("USED BAT: ");
  Serial.println(batteryVoltage, 3);
  Serial.print("USED PEM: ");
  Serial.println(pemrfcVoltage, 3);
  Serial.print("USED LOAD: ");
  Serial.println(loadVoltage, 3);



  priceReceived = true;
  return true;
}

void PrintValues() {
  Serial.print("PV Voltage: ");
  Serial.print(panelVoltage, 3);
  Serial.print(" Battery Voltage: ");
  Serial.print(batteryVoltage, 3);
  Serial.print(" Load Voltage: ");
  Serial.print(loadVoltage, 3);
  Serial.print(" PEM RFC Voltage: ");
  Serial.print(pemrfcVoltage, 3);
  Serial.print(" PV Current: ");
  Serial.print(PVcurrent, 3);
  Serial.print(" Battery Current: ");
  Serial.print(Batcurrent, 3);
  Serial.print(" Load Current: ");
  Serial.print(Loadcurrent, 3);
  Serial.print(" PEM Current: ");
  Serial.print(PEMcurrent, 3);
  Serial.print(" Electricity price: ");
  Serial.print(electricityprice, 3);
  Serial.print(" Hour: ");
  Serial.print(hour);
  Serial.print(" Price received: ");
  Serial.print(priceReceived);
  Serial.print(" Mode: ");
  Serial.println(mode);
}

// Scenario 1:
// Load receives power from grid, PV OFF, Battery OFF, PEM RFC OFF
void Scenario1() {
  mode = "Load receives power from grid PV OFF Battery OFF PEM RFC OFF";
  Serial.println("SCENARIO 1 ACTIVE");
  digitalWrite(LEDS1, HIGH);
  digitalWrite(LEDS2, LOW);
  digitalWrite(LEDS3, LOW);
  digitalWrite(LEDS4, LOW);
  digitalWrite(LEDS5, LOW);
  digitalWrite(LEDS6, LOW);
}

// Scenario 2:
// Load receives power from grid, PV Charges battery, PEM RFC OFF
void Scenario2() {
    
    Serial.println("Scenario 2 active");
  mode = "Load receives power from grid PV Charges battery PEM RFC OFF";
  Serial.println("SCENARIO 2 ACTIVE");
  digitalWrite(LEDS1, LOW);
  digitalWrite(LEDS2, HIGH);
  digitalWrite(LEDS3, LOW);
  digitalWrite(LEDS4, LOW);
  digitalWrite(LEDS5, LOW);
  digitalWrite(LEDS6, LOW);
}

// Scenario 3:
// Load receives power from grid, PV Charges PEM RFC, battery OFF
void Scenario3() {
  mode = "Load receives power from grid PV Charges PEM RFC battery OFF";
  Serial.println("SCENARIO 3 ACTIVE");
  digitalWrite(LEDS1, LOW);
  digitalWrite(LEDS2, LOW);
  digitalWrite(LEDS3, HIGH);
  digitalWrite(LEDS4, LOW);
  digitalWrite(LEDS5, LOW);
  digitalWrite(LEDS6, LOW);
}

// Scenario 4:
// Load receives power from PV only, battery OFF, PEM RFC OFF
void Scenario4() {
  mode = "Load receives power from PV battery OFF PEM RFC OFF";
  Serial.println("SCENARIO 4 ACTIVE");
  digitalWrite(LEDS1, LOW);
  digitalWrite(LEDS2, LOW);
  digitalWrite(LEDS3, LOW);
  digitalWrite(LEDS4, HIGH);
  digitalWrite(LEDS5, LOW);
  digitalWrite(LEDS6, LOW);
}

// Scenario 5:
// Load receives power from battery, PEM RFC OFF, PV OFF
void Scenario5() {
  mode = "Load receives power from battery PEM RFC OFF PV OFF";
  Serial.println("SCENARIO 5 ACTIVE");
  digitalWrite(LEDS1, LOW);
  digitalWrite(LEDS2, LOW);
  digitalWrite(LEDS3, LOW);
  digitalWrite(LEDS4, LOW);
  digitalWrite(LEDS5, HIGH);
  digitalWrite(LEDS6, LOW);
}

// Scenario 6:
// Load receives power from PEM , Battery OFF, PV OFF
void Scenario6() {
  mode = "Load receives power from PEM Battery OFF PV OFF";
  Serial.println("SCENARIO 6 ACTIVE");
  digitalWrite(LEDS1, LOW);
  digitalWrite(LEDS2, LOW);
  digitalWrite(LEDS3, LOW);
  digitalWrite(LEDS4, LOW);
  digitalWrite(LEDS5, LOW);
  digitalWrite(LEDS6, HIGH);
}