const currentPrice = document.getElementById("current-price");
const currentHour = document.getElementById("current-hour");
const bridgeOk = document.getElementById("bridge-ok");
const refreshBtn = document.getElementById("refresh-btn");

window.addEventListener("message", (event) => {
  const message = event.data;

  if (!message || message.type !== "telemetry") return;

  const payload = message.payload;
  currentPrice.textContent = payload.current_price;
  currentHour.textContent = payload.current_hour;
  bridgeOk.textContent = payload.runtime.bridge_ok;
});

refreshBtn.addEventListener("click", () => {
  parent.postMessage({
    type: "price_control",
    payload: {
      action: "refresh"
    }
  }, "*");
});

parent.postMessage({
  type: "state_request",
  payload: {}
}, "*");