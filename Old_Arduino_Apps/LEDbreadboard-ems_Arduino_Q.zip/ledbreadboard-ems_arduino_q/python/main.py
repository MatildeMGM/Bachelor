import threading
import time
from datetime import datetime
from pathlib import Path

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI

from prices import fetch_prices_for_today

ui = WebUI()

state_lock = threading.Lock()

runtime = {
    "prices": [],
    "price_zone": "DK2",
    "current_hour": 0,
    "current_price": 0.0,
    "price_source": "elprisenligenu.dk",
    "last_price_update": "",
    "bridge_ok": None,
    "last_error": "",
    "clients": 0,
    "panel_voltage": 0.0,
    "battery_voltage": 0.0,
    "pemrfc_voltage": 0.0,
    "load_voltage": 0.0,
    "pv_current": 0.0,
    "battery_current": 0.0,
    "pem_current": 0.0,
    "load_current": 0.0,
}

known_clients = set()

# /app/python/main.py -> parents[1] = /app
COMMAND_FILE = Path(__file__).resolve().parents[1] / "terminal_command.txt"


def build_payload():
    return {
        "runtime": {
            "clients": runtime["clients"],
            "bridge_ok": runtime["bridge_ok"],
            "last_error": runtime["last_error"],
            "price_zone": runtime["price_zone"],
            "price_source": runtime["price_source"],
            "last_price_update": runtime["last_price_update"],
        },
        "prices": runtime["prices"],
        "current_hour": runtime["current_hour"],
        "current_price": runtime["current_price"],
        "panel_voltage": runtime["panel_voltage"],
        "battery_voltage": runtime["battery_voltage"],
        "pemrfc_voltage": runtime["pemrfc_voltage"],
        "load_voltage": runtime["load_voltage"],
        "pv_current": runtime["pv_current"],
        "battery_current": runtime["battery_current"],
        "pem_current": runtime["pem_current"],
        "load_current": runtime["load_current"],
    }


def send_telemetry():
    ui.send_message("telemetry", build_payload())


def push_price_to_mcu():
    payload = "PRICE,{price:.5f},{hour}".format(
        price=runtime["current_price"],
        hour=runtime["current_hour"],
    )

    print("SENDING PRICE TO MCU:", payload)

    try:
        Bridge.call("apply_price_frame", payload, timeout=2)
        runtime["bridge_ok"] = True
    except Exception as e:
        runtime["bridge_ok"] = False
        runtime["last_error"] = f"Bridge error: {e}"


def push_control_to_mcu():
    payload = (
        "CTRL,{price:.5f},{hour},"
        "{pv:.5f},{bat:.5f},{pem:.5f},{load:.5f},"
        "{bat_i:.5f},{pem_i:.5f},{pv_i:.5f},{load_i:.5f}"
    ).format(
        price=runtime["current_price"],
        hour=runtime["current_hour"],
        pv=runtime["panel_voltage"],
        bat=runtime["battery_voltage"],
        pem=runtime["pemrfc_voltage"],
        load=runtime["load_voltage"],
        bat_i=runtime["battery_current"],
        pem_i=runtime["pem_current"],
        pv_i=runtime["pv_current"],
        load_i=runtime["load_current"],
    )

    print("SENDING CONTROL TO MCU:", payload)

    try:
        Bridge.call("apply_control_frame", payload, timeout=2)
        runtime["bridge_ok"] = True
    except Exception as e:
        runtime["bridge_ok"] = False
        runtime["last_error"] = f"Bridge error: {e}"


def update_current_hour_and_price():
    runtime["current_hour"] = datetime.now().hour

    if runtime["prices"] and len(runtime["prices"]) > runtime["current_hour"]:
        runtime["current_price"] = runtime["prices"][runtime["current_hour"]]
    else:
        runtime["current_price"] = 0.0


def refresh_prices():
    try:
        prices = fetch_prices_for_today(zone=runtime["price_zone"])

        with state_lock:
            runtime["prices"] = prices
            runtime["last_price_update"] = datetime.now().isoformat(timespec="seconds")
            runtime["last_error"] = ""

            update_current_hour_and_price()

    except Exception as e:
        runtime["last_error"] = f"Price fetch failed: {e}"


def publish_state(push_bridge=True, update_price=True):
    with state_lock:
        if update_price:
            update_current_hour_and_price()

        if push_bridge:
            push_price_to_mcu()
            push_control_to_mcu()

        payload = build_payload()

    ui.send_message("telemetry", payload)


def heartbeat_loop():
    while True:
        try:
            Bridge.call("heartbeat", timeout=1)
        except Exception:
            pass
        time.sleep(0.5)


def price_loop():
    last_refresh_date = None

    while True:
        try:
            today = datetime.now().date()

            if last_refresh_date != today or not runtime["prices"]:
                refresh_prices()
                last_refresh_date = today

            # Normal drift: brug API-prisen
            publish_state(push_bridge=True, update_price=True)

        except Exception as e:
            runtime["last_error"] = str(e)
            try:
                send_telemetry()
            except Exception:
                pass

        time.sleep(10)


def handle_terminal_file(content: str):
    manual_price_present = False
    updated = False

    with state_lock:
        for raw_line in content.splitlines():
            line = raw_line.strip()

            if not line or "=" not in line:
                continue

            key, value = line.split("=", 1)
            key = key.strip().lower()
            value = value.strip()

            try:
                if key == "price":
                    runtime["current_price"] = float(value)
                    manual_price_present = True
                    updated = True

                elif key == "hour":
                    runtime["current_hour"] = int(value)
                    updated = True

                elif key == "pv":
                    runtime["panel_voltage"] = float(value)
                    updated = True

                elif key == "bat":
                    runtime["battery_voltage"] = float(value)
                    updated = True

                elif key == "pem":
                    runtime["pemrfc_voltage"] = float(value)
                    updated = True

                elif key == "load":
                    runtime["load_voltage"] = float(value)
                    updated = True

                elif key == "pvi":
                    runtime["pv_current"] = float(value)
                    updated = True

                elif key == "bati":
                    runtime["battery_current"] = float(value)
                    updated = True

                elif key == "pemi":
                    runtime["pem_current"] = float(value)
                    updated = True

                elif key == "loadi":
                    runtime["load_current"] = float(value)
                    updated = True

                elif key == "zone":
                    zone = value.upper()
                    if zone in ["DK1", "DK2"]:
                        runtime["price_zone"] = zone
                        refresh_prices()
                        updated = True
                    else:
                        runtime["last_error"] = f"Invalid price zone: {value}"

                else:
                    runtime["last_error"] = f"Unknown key in terminal_command.txt: {key}"

            except ValueError:
                runtime["last_error"] = f"Invalid value for {key}: {value}"

    if updated:
        print("TERMINAL FILE RECEIVED:")
        print(content)

        # Hvis price står i filen -> brug manuel price
        # Ellers -> brug API-price
        publish_state(push_bridge=True, update_price=not manual_price_present)


def terminal_command_loop():
    COMMAND_FILE.touch(exist_ok=True)
    last_seen = ""

    while True:
        try:
            current = COMMAND_FILE.read_text(encoding="utf-8").strip()

            if current and current != last_seen:
                handle_terminal_file(current)
                last_seen = current

        except Exception as e:
            runtime["last_error"] = f"Command file error: {e}"

        time.sleep(1)


def on_state_request(client_id, data):
    known_clients.add(client_id)
    runtime["clients"] = len(known_clients)
    send_telemetry()


def on_price_control(client_id, data):
    known_clients.add(client_id)
    runtime["clients"] = len(known_clients)

    action = (data or {}).get("action", "")

    if action == "refresh":
        refresh_prices()
        publish_state(push_bridge=True)

    elif action == "set_zone":
        zone = (data or {}).get("zone", "DK2")
        if zone in ["DK1", "DK2"]:
            runtime["price_zone"] = zone
            refresh_prices()
            publish_state(push_bridge=True)
        else:
            runtime["last_error"] = "Invalid price zone"
            send_telemetry()

    else:
        send_telemetry()


ui.on_message("state_request", on_state_request)
ui.on_message("price_control", on_price_control)

threading.Thread(target=heartbeat_loop, daemon=True).start()
threading.Thread(target=price_loop, daemon=True).start()
threading.Thread(target=terminal_command_loop, daemon=True).start()

App.run()